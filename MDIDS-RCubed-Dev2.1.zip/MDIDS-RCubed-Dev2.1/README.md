####### MDIDS-RCubed
