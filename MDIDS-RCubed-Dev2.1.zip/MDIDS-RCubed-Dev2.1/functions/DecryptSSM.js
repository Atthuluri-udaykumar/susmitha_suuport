// eslint-disable-next-line import/no-extraneous-dependencies
const AWS = require('aws-sdk');

AWS.config.update({
  region: 'us-east-2'
});

const parameterStore = new AWS.SSM();

const getDecryptParam = (param) => new Promise((res, rej) => {
  console.log(`getDecryptParam(${param}`);
  parameterStore.getParameter({
    Name: param,
    WithDecryption: true
  }, (err, data) => {
    if (err) {
      console.log('Error in decryptParam');
      return rej(err);
    }
    return res(data.Parameter.Value);
  });
});


/* const getParameterWorker = async (name:string, decrypt:boolean) : Promise<string> => {
    const ssm = new SSM();
    const result = await ssm
        .getParameter({ Name: name, WithDecryption: decrypt })
        .promise();
    return result.Parameter.Value;
} */

/* exports.getParameter = async(name) => {
    return getParameterWorker(name,false);
} */

exports.getEncryptedParameter = async (name) => getDecryptParam(name);
