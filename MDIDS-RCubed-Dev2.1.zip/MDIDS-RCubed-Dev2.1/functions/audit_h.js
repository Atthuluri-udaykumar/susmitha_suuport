const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

exports.getAuditTable = async () => {
  console.log('get audit table');
  const client = await createClient();
  await client.connect();
  const q1 = knex.select().from('rcubed_audit.logged_actions ');
  const r = await client.query(q1.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getAuditRange = async (startDate, endDate) => {
  console.log('get audit range start');
  const client = await createClient();
  await client.connect();
  const q1 = knex.select()
    .from('rcubed_audit.logged_actions')
    .where('action_tstamp_stm', '<=', endDate)
    .where('action_tstamp_stm', '>=', startDate);
  console.log(q1.toQuery());
  const r = await client.query(q1.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};
