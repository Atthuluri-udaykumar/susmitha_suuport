const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const { Client } = require('pg');
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.allCountries = async () => {
  console.log('All Countries Called!!');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.HUB_COUNTRIES')
    .orderBy('COUNTRY_NM');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT * from rcubed.HUB_COUNTRIES order by COUNTRY_NM');
  // return result;
};

exports.allActiveCountries = async () => {
  const client = await createClient();
  await client.connect();
  const q = knex.select()
    .from('rcubed.HUB_COUNTRIES')
    .where('IS_ACTIVE', true);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query(
  //   'SELECT * FROM rcubed.HUB_COUNTRIES WHERE IS_ACTIVE = :yes order by COUNTRY_NM',
  //   { yes: true }
  //
  // );
  // return result;
};

exports.getCountry = async (id) => {
  console.log(`Get Country ${id}`);
  const client = await createClient();
  await client.connect();
  const q = knex.select()
    .from('rcubed.HUB_COUNTRIES')
    .where('COUNTRIES_ID', id);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query(
  //   'SELECT * FROM rcubed.HUB_COUNTRIES WHERE COUNTRIES_ID = :id',
  //   { id }
  // );
  // return result;
};

exports.updateCountryRegion = async (active, region_id, countryId, lilly_id) => {
  const isTrue = active === 'true';
  let region = null;
  if (region_id !== 0) {
    region = region_id;
  }
  const q = knex('rcubed.HUB_COUNTRIES')
    .where('countries_id', countryId)
    .update({
      IS_ACTIVE: isTrue,
      REGION: region
    });
  return createUpdate(lilly_id, q);
  // const result = await data.query('UPDATE rcubed.HUB_COUNTRIES SET IS_ACTIVE=:active, REGION = :region_id where countries_id=:id',
  //   { region_id: region, active: isTrue, id: countryId });
  //
  // return result;
};

exports.getAllCountriesInRegion = async (regionId) => {
  console.log('getAllCountriesInRegion');
  const client = await createClient();
  await client.connect();
  const q = knex.select()
    .from('HUB_COUNTRIES')
    .where('REGION', regionId)
    .orderBy('COUNTRY_NM');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT * from rcubed.HUB_COUNTRIES where REGION = :region_id order by COUNTRY_NM',
  //   { region_id: regionId });
  // return result;
};

exports.getAllCountriesWithoutRegion = async () => {
  console.log('Get all countries without region');
  const client = await createClient();
  await client.connect();
  const q = knex.select()
    .from('rcubed.HUB_COUNTRIES')
    .where('REGION', null)
    .orderBy('COUNTRY_NM');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT * from rcubed.HUB_COUNTRIES where REGION=NULL order by COUNTRY_NM');
  // return result;
};
