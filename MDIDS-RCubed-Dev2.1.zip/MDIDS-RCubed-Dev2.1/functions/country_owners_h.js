// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const { Client } = require('pg');
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;

  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getAllCountiresOwners = async () => {
  console.log('get all country owner function');
  const q = knex.distinct('co.user_id', 'u.user_nm', 'co.countries_id', 'c.country_nm')
    .from({ co: 'rcubed.COUNTRY_OWNERS' })
    .join({ u: 'rcubed.USERS' }, 'u.user_id', '=', 'co.user_id')
    .join({ c: 'rcubed.HUB_COUNTRIES' }, 'c.countries_id', '=', 'co.countries_id');

  // const result = await data.query(
  //   'SELECT co.user_id, u.user_nm, co.countries_id, c.country_nm '
  //       + 'from rcubed.COUNTRY_OWNERS as co '
  //       + 'left Join rcubed.USERS as u ON u.user_id = co.user_id '
  //       + 'left JOIN rcubed.COUNTRIES as c ON c.countries_id = co.countries_id'
  // );
  console.log(`query = ${q.toQuery()}`);
  const client = await createClient();
  await client.connect();
  const result = {};
  const r = await client.query(q.toQuery());
  result.records = r.rows;
  client.end();
  return result;
};

exports.GetCountriesForUser = async (user_id) => {
  const client = await createClient();
  await client.connect();
  const q = knex.select('co.user_id', 'u.user_nm', 'co.countries_id',
    'c.country_nm')
    .from({ co: 'rcubed.COUNTRY_OWNERS' })
    .leftJoin({ u: 'rcubed.USERS' }, 'u.user_id', '=',
      'co.user_id')
    .leftJoin({ c: 'rcubed.HUB_COUNTRIES' }, 'c.countries_id', '=',
      'co.countries_id')
    .where('co.user_id', user_id);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.GetUserForCountry = async (countries_id) => {
  console.log('get owners for country: ', countries_id);
  const client = await createClient();
  await client.connect();
  const q = knex.select('co.user_id', 'u.user_nm', 'co.countries_id',
    'c.country_nm')
    .from({ co: 'rcubed.COUNTRY_OWNERS' })
    .leftJoin({ u: 'rcubed.USERS' }, 'u.user_id', '=',
      'co.user_id')
    .leftJoin({ c: 'rcubed.HUB_COUNTRIES' }, 'c.countries_id', '=',
      'co.countries_id')
    .where('co.countries_id', countries_id);
  const r = await client.query(q.toQuery());

  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.CreateCountryOwner = async (user_id, country_id, lilly_id) => {
  console.log('create country owner function');
  const q = knex
    .insert({
      user_id,
      countries_id: country_id
    }).into('rcubed.COUNTRY_OWNERS');
  return createUpdate(lilly_id, q);
};

exports.RemoveCountryOwner = async (userid, country_id) => {
  console.log('remove country owner function');
  const client = await createClient();
  await client.connect();
  const q = knex('rcubed.COUNTRY_OWNERS')
    .where('user_id', userid)
    .where('countries_id', country_id)
    .del();
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};
