const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const { Client } = require('pg');
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getAllDosageForms = async () => {
  console.log('Get all Dosage forms');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.DOSAGE_FORM_LST');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT * from rcubed.DOSAGE_FORM_LST');
  // return result;
};

exports.getActiveDosageForms = async () => {
  console.log('Get active dosage forms');
  const client = await createClient();
  await client.connect();
  const q = knex.select('DOSAGE_FRM_LST_ID', 'DOSAGE_FRM_LST_NM')
    .from('rcubed.DOSAGE_FORM_LST')
    .where('IS_ACTIVE', true);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getDosageForm = async (dosage_frm_lst_id) => {
  console.log(`get doasage form: ${dosage_frm_lst_id}`);
  const client = await createClient();
  await client.connect();
  const q = knex.select('DOSAGE_FRM_LST_NM', 'IS_ACTIVE')
    .from('rcubed.DOSAGE_FORM_LST')
    .where('dosage_frm_lst_id', dosage_frm_lst_id);
  const r = await client.query(q.toQuery());
  const result = {};
  result.record = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT DOSAGE_FRM_LST_NM, ACTIVE from rcubed.DOSAGE_FORM_LST '
  //   + 'where dosage_frm_lst_id = :dosage_frm_lst_id', { dosage_frm_lst_id });
  // return result;
};

exports.updateDosageForm = async (dosage_frm_lst_id, dosage_frm_lst_nm, active, lilly_id) => {
  console.log(`Update dosage form: ${dosage_frm_lst_id}`);
  const isTrue = active === 'true';
  const q = knex('rcubed.DOSAGE_FORM_LST')
    .where('dosage_frm_lst_id', dosage_frm_lst_id)
    .update({
      dosage_frm_lst_nm,
      is_active: isTrue,
    });
  return createUpdate(lilly_id, q);
};

exports.addDosageForm = async (dosage_frm_lst_nm, lilly_id) => {
  console.log('Add dosage form');
  const q = knex
    .insert({
      DOSAGE_FRM_LST_NM: dosage_frm_lst_nm
    }).into('rcubed.DOSAGE_FORM_LST');
  return createUpdate(lilly_id, q);
  // const result = await data.query('INSERT INTO rcubed.DOSAGE_FORM_LST (DOSAGE_FRM_LST_NM) '
  //       + 'VALUES(:dosage_frm_lst_nm)', { dosage_frm_lst_nm });
  // return result;
};
