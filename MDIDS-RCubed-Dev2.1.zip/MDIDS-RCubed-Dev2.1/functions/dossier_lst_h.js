const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getAllDossierList2 = async () => {
  console.log(' Get al Dossier list ltree');
  const client = await createClient();
  await client.connect();
  const r = await client.query('SELECT * FROM rcubed.dossier_lst2 WHERE parent_path <@ \'root\' ORDER BY nlevel(parent_path),DOSSIER_LST_ID');
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT * FROM rcubed.dossier_lst2 WHERE parent_path <@ \'root\' ORDER BY nlevel(parent_path),DOSSIER_LST_ID');
  // return result;
};

exports.addDossierToList = async (parent_id, dossier_lst_nm, active, lilly_id) => {
  console.log('Add Dossier ');
  const isTrue = active === 'true';
  let p_id = null;
  if (parent_id === 0) {
    p_id = null;
  } else {
    p_id = parent_id;
  }
  const q = knex
    .insert({
      PARENT_ID: p_id,
      DOSSIER_LST_NM: dossier_lst_nm,
      IS_ACTIVE: isTrue
    }).into('rcubed.dossier_lst2');
  return createUpdate(lilly_id, q);
};

exports.updateDossierListNode = async (parent_id, dossier_lst_nm, active,
  dossier_lst_id, lilly_id) => {
  console.log('Update Dossier list Node');
  const is_true = active === 'true';
  let p_id = null;
  if (parent_id !== 0) {
    p_id = parent_id;
  }
  const q = knex('rcubed.dossier_lst2').where('dossier_lst_id', '=', dossier_lst_id);
  q.update({
    parent_id: p_id,
    dossier_lst_nm,
    is_active: is_true
  });
  return createUpdate(lilly_id, q);
  // const result = await data.query(q.toQuery());
  // return result;
};
