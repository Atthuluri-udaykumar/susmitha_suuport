const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getAllGeneralRequirementCategoryList = async () => {
  console.log('Get all General Requirement Category List');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.GEN_REQUIREMENT_CAT_LST');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT * from rcubed.GEN_REQUIREMENT_CAT_LST ');
  // return result;
};

exports.getActiveGeneralRequirementCategoryList = async () => {
  console.log('Get active general requirement category list');
  const client = await createClient();
  await client.connect();
  const q = knex.select('GEN_REQ_CAT_LST_ID', 'GEN_REQ_CAT_LST_NM')
    .from('rcubed.GEN_REQUIREMENT_CAT_LST')
    .where('IS_ACTIVE', true);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('select GEN_REQ_CAT_LST_ID, GEN_REQ_CAT_LST_NM FROM '
  //   + 'rcubed.GEN_REQUIREMENT_CAT_LST where IS_ACTIVE =:yes', { yes: true });
  // return result;
};

exports.getGeneralRequirementCategory = async (GEN_REQ_CAT_LST_ID) => {
  console.log(`Get general requirement category: ${GEN_REQ_CAT_LST_ID}`);
  const client = await createClient();
  await client.connect();
  const q = knex.select('GEN_REQ_CAT_LST_NM', 'IS_ACTIVE')
    .from('rcubed.GEN_REQUIREMENT_CAT_LST')
    .where('GEN_REQ_CAT_LST_ID', GEN_REQ_CAT_LST_ID);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
  // const result = await data.query('SELECT GEN_REQ_CAT_LST_NM, ACTIVE from rcubed.GEN_REQUIREMENT_CAT_LST '
  //   + 'where GEN_REQ_CAT_LST_ID = :GEN_REQ_CAT_LST_ID', { GEN_REQ_CAT_LST_ID });
  // return result;
};

// eslint-disable-next-line max-len
exports.updateGeneralRequirementCategory = async (GEN_REQ_CAT_LST_ID, GEN_REQ_CAT_LST_NM, ACTIVE, lilly_id) => {
  console.log(`Update general requirement category list: ${GEN_REQ_CAT_LST_ID}`);
  const isTrue = ACTIVE === 'true';
  const q = knex('rcubed.GEN_REQUIREMENT_CAT_LST')
    .where('GEN_REQ_CAT_LST_ID', GEN_REQ_CAT_LST_ID)
    .update({
      GEN_REQ_CAT_LST_NM,
      IS_ACTIVE: isTrue
    });
  await createUpdate(lilly_id,q);
  return '1 row updated';
  // const result = await data.query('UPDATE rcubed.GEN_REQUIREMENT_CAT_LST '
  //   + 'SET GEN_REQ_CAT_LST_NM = :GEN_REQ_CAT_LST_NM, IS_ACTIVE = :ACTIVE where GEN_REQ_CAT_LST_ID = :GEN_REQ_CAT_LST_ID',
  // { GEN_REQ_CAT_LST_ID, GEN_REQ_CAT_LST_NM, ACTIVE: isTrue });
  // return result;
};

exports.addGeneralRequirementCategory = async (GEN_REQ_CAT_LST_NM, lilly_id) => {
  console.log('Add general requirement category');
  const q = knex
    .insert({
      GEN_REQ_CAT_LST_NM
    }).into('rcubed.GEN_REQUIREMENT_CAT_LST');
  await createUpdate(lilly_id,q);
  return 'one row inserted';
  // const result = await data.query('INSERT into rcubed.GEN_REQUIREMENT_CAT_LST (GEN_REQ_CAT_LST_NM) '
  //       + 'VALUES( :GEN_REQ_CAT_LST_NM) ', { GEN_REQ_CAT_LST_NM });
  // return result;
};
