// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

const getsubTemp = require('./getSubmissionRequirementTemplate');

exports.getSubmissionForm = async (sub_form_id, is_current, active_questions) => {
  console.log('start get submission form');
  let result1;
  const result = {};
  console.log(`Sub_form_id = ${sub_form_id}`);
  let r2;
  const client = await createClient();
  await client.connect();
  let q1 = knex.select('sf.SUB_REQ_FORMS_ID', 'sf.SUB_TYP_ID', 'sf.sub_req_forms_nm', 'st.SUB_TYP_NM')
    .from({ sf: 'rcubed.SUB_REQ_FORMS' })
    .join({ st: 'rcubed.SUBMISSION_TYPE' }, 'sf.SUB_TYP_ID', '=', 'st.SUB_TYP_ID')
    .where('sf.SUB_REQ_FORMS_ID', sub_form_id);
  let q2 = knex.select('ptr.PRODUCT_TYPE_ID', 'pt.PRODUCT_TYPE_NM')
    .from({ ptr: 'rcubed.SUB_REQ_FORMS_PRODUCT_TYPE_REF' })
    .join({ pt: 'rcubed.PRODUCT_TYPE' }, 'ptr.PRODUCT_TYPE_ID', '=', 'pt.PRODUCT_TYPE_ID')
    .where('ptr.SUB_REQ_FORMS_ID', sub_form_id);
  try {
    result1 = await client.query(q1.toQuery());
    console.log(`q1 = ${q1.toQuery()}`);
    result.records = result1.rows[0];
    console.log(`q2 = ${q2.toQuery()}`);
    r2 = await client.query(q2.toQuery());
    result.records.PRODUCT_TYPE = r2.rows;
    console.log('get submission form - Dossier');
    q2 = knex.select('dlr.DOSSIER_LST_ID', 'dl.DOSSIER_LST_NM')
      .from({ dlr: 'rcubed.SUB_REQ_FORMS_DOSSIER_REF' })
      .join({ dl: 'rcubed.DOSSIER_LST2' }, 'dlr.DOSSIER_LST_ID', '=', 'dl.DOSSIER_LST_ID')
      .where('dlr.SUB_REQ_FORMS_ID', sub_form_id);
    r2 = await client.query(q2.toQuery());

    result.records.DOSSIER_REF = r2.rows;

    console.log('get submission form - question list');
    // const q3 = 'select * from rcubed.SUB_REQ_FORMS_QSTN_LST '
    // + 'where SUB_REQ_FORMS_ID = :sub_form_id '
    // + 'and is_active = true '
    // + 'and is_current = :is_current';
    q1 = knex.select().from('rcubed.SUB_REQ_FORMS_QSTN_LST')
      .where('SUB_REQ_FORMS_ID', sub_form_id)
      .where('is_active', true)
      .where('is_current', is_current);

    // const q2 = 'select * from rcubed.SUB_REQ_FORMS_QSTN_LST '
    //     + 'where SUB_REQ_FORMS_ID = :sub_form_id '
    //     + 'and is_current = :is_current';
    q2 = knex.select().from('rcubed.SUB_REQ_FORMS_QSTN_LST')
      .where('SUB_REQ_FORMS_ID', sub_form_id)
      .where('is_current', is_current);
    if (active_questions === true) {
      // r2 = await data.query(q1, { sub_form_id, is_current });
      r2 = await client.query(q1.toQuery());
    } else {
      // r2 = await data.query(q2, { sub_form_id, is_current });
      r2 = await client.query(q2.toQuery());
    }
    console.log(`FORMS_QSTN_LST Pre: ${JSON.stringify(r2)}`);
    const rows = {};
    // delete Object.assign(r2, { FORMS_QSTN_LST: r2.rows }).rows;
    rows.FORMS_QSTN_LST = r2.rows;
    console.log(`FORMS_QSTN_LST: ${JSON.stringify(rows)}`);
    console.log('get submission form - getSubmissionRequirementTemplate');
    const d = JSON.parse(JSON.stringify(rows));
    console.log(`D: ${JSON.stringify(d)}`);
    for (let i = 0; i < d.FORMS_QSTN_LST.length; i += 1) {
      console.log(`i = ${i}`);
      // eslint-disable-next-line prefer-destructuring
      const submission_req_tmplt_id = d.FORMS_QSTN_LST[i].submission_req_tmplt_id;
      console.log(`SUBMISSION_REQ_TMPLT_ID: ${submission_req_tmplt_id}`);
      // eslint-disable-next-line no-await-in-loop
      const r3 = await getsubTemp.getSubmissionRequirementTemplate(submission_req_tmplt_id, true);
      // delete Object.assign(r3, { SUBMISSION_REQ_TMPLT: r3.records }).records;
      rows.FORMS_QSTN_LST[i].SUBMISSION_REQ_TMPLT = r3.rows;
    }
    result.records.FORMS_QSTN_LST = rows;
  } catch (err) {
    console.log(`SQL error in update  Submission Requirement  ${err}`);
    return err;
  }
  client.end();
  return result;
};
