// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

exports.getSubmissionRequirementTemplate = async (sub_id, isTrue) => {
  console.log(`Get Submission Requirement template: ${sub_id}`);
  const client = await createClient();
  await client.connect();
  let query1 = knex.select('st.SUBMISSION_REQ_TMPLT_ID', 'st.REQ_QUESTION_TYPE_LST_ID',
    'rql.REQ_QUESTION_TYPE_NM', 'st.REQ_TYPE', 'st.CUSTOM_ALLOWED')
    .from({ st: 'rcubed.SUBMISSION_REQ_TMPLT' })
    .leftJoin({ rql: 'rcubed.REQ_QUESTION_TYPE_LST' }, 'st.REQ_QUESTION_TYPE_LST_ID', '=',
      'rql.REQ_QUESTION_TYPE_LST_ID')
    .where('st.SUBMISSION_REQ_TMPLT_ID', sub_id);
  // const query1 = 'Select st.SUBMISSION_REQ_TMPLT_ID, st.REQ_QUESTION_TYPE_LST_ID, rql.REQ_QUESTION_TYPE_NM,'
  //       + 'st.REQ_TYPE,st.CUSTOM_ALLOWED '
  //       + 'from rcubed.SUBMISSION_REQ_TMPLT st LEFT JOIN rcubed.REQ_QUESTION_TYPE_LST rql '
  //       + 'ON st.REQ_QUESTION_TYPE_LST_ID = rql.REQ_QUESTION_TYPE_LST_ID '
  //       + 'where st.SUBMISSION_REQ_TMPLT_ID =:sub_id'
  let query2 = knex.select('st.SUBMISSION_REQ_TMPLT_ID', 'st.REQ_QUESTION_TYPE_LST_ID',
    'rql.REQ_QUESTION_TYPE_NM', 'st.REQ_TYPE', 'st.CUSTOM_ALLOWED')
    .from({ st: 'rcubed.SUBMISSION_REQ_TMPLT' })
    .leftJoin({ rql: 'rcubed.REQ_QUESTION_TYPE_LST' }, 'st.REQ_QUESTION_TYPE_LST_ID', '=',
      'rql.REQ_QUESTION_TYPE_LST_ID')
    .where('st.SUBMISSION_REQ_TMPLT_ID', sub_id)
    .where('st.is_active', isTrue);
  // const query2 = 'Select st.SUBMISSION_REQ_TMPLT_ID, st.REQ_QUESTION_TYPE_LST_ID, rql.REQ_QUESTION_TYPE_NM,'
  //       + 'st.REQ_TYPE,st.CUSTOM_ALLOWED '
  //       + 'from rcubed.SUBMISSION_REQ_TMPLT st LEFT JOIN rcubed.REQ_QUESTION_TYPE_LST rql '
  //       + 'ON st.REQ_QUESTION_TYPE_LST_ID = rql.REQ_QUESTION_TYPE_LST_ID '
  //       + 'where st.SUBMISSION_REQ_TMPLT_ID =:sub_id and st.IS_ACTIVE = :active';
  let result1;
  const result = {};
  if (isTrue) {
    console.log(`main query query 2 = ${query2.toQuery()}`);
    // result1 = await data.query(query2, { sub_id, active: true });
    result1 = await client.query(query2.toQuery());
  } else {
    // result1 = await data.query(query1, { sub_id });
    result1 = await client.query(query1.toQuery());
  }
  // eslint-disable-next-line prefer-destructuring
  result.records = result1.rows[0];
  console.log(`result after 1st query ${JSON.stringify(result)}`);
  let result2;
  query1 = knex.select().from('rcubed.REQ_QSTN_LST_TXT')
    .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
    .where('is_active', true);
  query2 = knex.select().from('rcubed.REQ_QSTN_LST_TXT')
    .where('SUBMISSION_REQ_TMPLT_ID', sub_id);
  if (isTrue) {
    console.log(`question list query istrue = ${query1.toQuery()}`);
    // result2 = await data.query('Select * from rcubed.REQ_QSTN_LST_TXT where SUBMISSION_REQ_TMPLT_ID = :sub_id '
    //      + 'and IS_ACTIVE = :active', { sub_id, active: true });
    result2 = await client.query(query1.toQuery());
  } else {
    // result2 = await data.query('Select * from rcubed.REQ_QSTN_LST_TXT where SUBMISSION_REQ_TMPLT_ID = :sub_id ',
    //   { sub_id });
    result2 = await client.query(query2.toQuery());
  }
  let a = [];
  console.log(`result after 2nd query ${JSON.stringify(result2)}`);

  result.records.qstn_txt = result2.rows;
  // delete Object.assign(result2, { qstn_txt: result2.records }).records;
  // result.records.qstn_txt.push(result2.rows);
  console.log(`results for question text ${JSON.stringify(result)}`);
  // product type
  let r3 = knex.select('ptr.PRODUCT_TYPE_ID', 'pt.PRODUCT_TYPE_NM')
    .from({ ptr: 'rcubed.SUB_REQ_PRODUCT_TYP_REF' })
    .leftJoin({ pt: 'rcubed.PRODUCT_TYPE' }, 'ptr.PRODUCT_TYPE_ID', '=',
      'pt.PRODUCT_TYPE_ID')
    .where('ptr.SUBMISSION_REQ_TMPLT_ID', sub_id);
  // let r3 = await data.query('SELECT ptr.PRODUCT_TYPE_ID, pt.PRODUCT_TYPE_NM '
  //       + 'from rcubed.SUB_REQ_PRODUCT_TYP_REF ptr LEFT JOIN rcubed.PRODUCT_TYPE pt '
  //       + 'ON ptr.PRODUCT_TYPE_ID = pt.PRODUCT_TYPE_ID '
  //       + 'where ptr.SUBMISSION_REQ_TMPLT_ID = :sub_id', { sub_id });

  // delete Object.assign(r3, { PRODUCT_TYPE: r3.records }).records;
  result2 = await client.query(r3.toQuery());
  result.records.PRODUCT_TYPE = result2.rows;
  // submission type
  query1 = knex.select('str.SUB_TYP_ID', 'st.SUB_TYP_NM')
    .from({ str: 'rcubed.SUB_REQ_SUB_TYP_REF' })
    .leftJoin({ st: 'rcubed.SUBMISSION_TYPE' }, 'str.SUB_TYP_ID', '=',
      'st.SUB_TYP_ID')
    .where('str.SUBMISSION_REQ_TMPLT_ID', sub_id);
  r3 = await client.query(query1.toQuery());
  // r3 = await data.query('SELECT str.SUB_TYP_ID, st.SUB_TYP_NM '
  //       + 'from rcubed.SUB_REQ_SUB_TYP_REF str LEFT JOIN rcubed.SUBMISSION_TYPE st '
  //       + 'ON str.SUB_TYP_ID = st.SUB_TYP_ID '
  //       + 'where str.SUBMISSION_REQ_TMPLT_ID = :sub_id', { sub_id });

  // delete Object.assign(r3, { SUBMISSION_TYPE: r3.records }).records;

  result.records.SUBMISSION_TYPE = r3.rows;
  // REQ_CAT_LST
  query1 = knex.select('rclr.REQ_CAT_LST_ID', 'rcl.REQ_CAT_LST_NM')
    .from({ rclr: 'rcubed.SUB_REQ_REQ_CAT_REF' })
    .leftJoin({ rcl: 'rcubed.REQUIRMENT_CATEGORY_LIST' }, 'rclr.REQ_CAT_LST_ID', '=',
      'rcl.REQ_CAT_LST_ID')
    .where('rclr.SUBMISSION_REQ_TMPLT_ID', sub_id);
  r3 = await client.query(query1.toQuery());
  // r3 = await data.query('SELECT rclr.REQ_CAT_LST_ID, rcl.REQ_CAT_LST_NM '
  //       + 'from rcubed.SUB_REQ_REQ_CAT_REF rclr LEFT JOIN rcubed.REQUIRMENT_CATEGORY_LIST rcl '
  //       + 'ON rclr.REQ_CAT_LST_ID = rcl.REQ_CAT_LST_ID '
  //       + 'where rclr.SUBMISSION_REQ_TMPLT_ID = :sub_id', { sub_id });
  // delete Object.assign(r3, { REQ_CAT_LST: r3.records }).records;

  result.records.REQ_CAT_LST = r3.rows;
  // Dossier List
  query1 = knex.select('dlr.DOSSIER_LST_ID', 'dl.DOSSIER_LST_NM')
    .from({ dlr: 'rcubed.SUB_REQ_DOSSIER_REF' })
    .leftJoin({ dl: 'rcubed.DOSSIER_LST2' }, 'dlr.DOSSIER_LST_ID', '=',
      'dl.DOSSIER_LST_ID')
    .where('dlr.SUBMISSION_REQ_TMPLT_ID', sub_id);
  r3 = await client.query(query1.toQuery());
  // r3 = await data.query('SELECT dlr.DOSSIER_LST_ID, dl.DOSSIER_LST_NM '
  //       + 'from rcubed.SUB_REQ_DOSSIER_REF dlr LEFT JOIN rcubed.DOSSIER_LST2 dl '
  //       + 'ON dlr.DOSSIER_LST_ID = dl.DOSSIER_LST_ID '
  //       + 'where dlr.SUBMISSION_REQ_TMPLT_ID = :sub_id', { sub_id });
  // delete Object.assign(r3, { DOSSIER_LST: r3.records }).records;
  result.records.DOSSIER_LST = r3.rows;
  // general requirement cat list
  query1 = knex.select('grr.GEN_REQ_CAT_LST_ID', 'grcl.GEN_REQ_CAT_LST_NM')
    .from({ grr: 'rcubed.SUB_REQ_GEN_REQ_CAT_REF' })
    .leftJoin({ grcl: 'rcubed.GEN_REQUIREMENT_CAT_LST' }, 'grr.GEN_REQ_CAT_LST_ID', '=',
      'grcl.GEN_REQ_CAT_LST_ID')
    .where('grr.SUBMISSION_REQ_TMPLT_ID', sub_id);
  r3 = await client.query(query1.toQuery());
  // r3 = await data.query('SELECT grr.GEN_REQ_CAT_LST_ID, grcl.GEN_REQ_CAT_LST_NM '
  //     + 'from rcubed.SUB_REQ_GEN_REQ_CAT_REF grr LEFT JOIN rcubed.GEN_REQUIREMENT_CAT_LST grcl '
  //     + 'ON grr.GEN_REQ_CAT_LST_ID = grcl.GEN_REQ_CAT_LST_ID '
  //     + 'where grr.SUBMISSION_REQ_TMPLT_ID = :sub_id', { sub_id });
  // delete Object.assign(r3, { GEN_REQ_CAT_LST: r3.records }).records;

  result.records.GEN_REQ_CAT_LST = r3.rows;
  client.end();
  return result;
};
