// eslint-disable-next-line import/no-extraneous-dependencies
const { Readable } = require('stream');
const { createWriteStream } = require('fs');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { Buffer } = require('buffer');

const axios = require('axios');
const https = require('https');
const fs = require('fs');

const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function streamToString(stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', (chunk) => chunks.push(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
  });
}

module.exports.HubCountry = async (event, context) => {
  let options;
  const cntry_desc = [];
  let httpsAgent;
  try {
    console.log('> Getting content from S3');
    const s3Client = new S3Client({
      region: 'us-east-2',
    });
    let command = new GetObjectCommand({
      Key: 'lib/rcubed.lilly.com.crt',
      Bucket: 'lly-regulatory-dev',
    });
    console.log('>>Getting Cert command');
    const hcert = await s3Client.send(command);
    hcert.Body.pipe(createWriteStream('/tmp/rcubed.lilly.com.crt'));
    const theCert = await streamToString(hcert.Body);
    console.log(`theCert = ${theCert}`);
    command = new GetObjectCommand({
      Key: 'lib/rcube-srv-key.pem',
      Bucket: 'lly-regulatory-dev',
    });
    console.log('Get Key');
    const ckey = await s3Client.send(command);
    const theKey = await streamToString(ckey.Body);
    console.log(`key >> ${theKey}`);
    await ckey.Body.pipe(createWriteStream('/tmp/rcube-srv-key.pem'));
    console.log('initializing Agent');
    httpsAgent = new https.Agent(
      {
        key: theKey,
        cert: theCert,
        keepAlive: true
      }
    );
    console.log('httpAgent done');
  } catch (err) {
    console.log('error', err);
  }
  // key: await ckey.Body.pipe(createWriteStream('/tmp/rcube-srv-key.pem')),
  // cert: await hcert.Body.pipe(createWriteStream('/tmp/rcubed.lilly.com.crt')),
  // cert: fs.readFileSync('/tmp/rcubed.lilly.com.crt'),
  const hubPW = await decryptPW.getEncryptedParameter(process.env.hub_pw_path);

  // eslint-disable-next-line prefer-const
  options = {
    method: 'post',
    // url: 'https://gateway-v2-qa.lillyapi.com/mdidsihub-dev/v1/rest/edb-md-clinical/c-lkp-cntry',
    url: process.env.hub_url,
    auth: {
      username: process.env.hub_username,
      password: hubPW
    },
    httpsAgent,
    responseType: 'json',

  };
  let data2;
  const client = await createClient();
  await client.connect();
  try {
    const res = await axios(options);
    console.log('headers', res.headers);
    data2 = res.data;
    console.log('data: ', data2);
    data2.data.forEach((country) => {
      cntry_desc.push(country.cntry_shrt_desc);
    });
    // console.log('data:', cntry_desc.join());
  } catch (err) {
    console.log('error', err);
  }

  // Store in DB
  // makes array into a string and removes the front and back []
  try {
    // load new countries into table
    console.log('Hub_countries: load new counties into table');
    for (let i = 0; i < cntry_desc.length; i += 1) {
      const q = knex.insert({
        country_nm: cntry_desc[i]
      }).into('rcubed.HUB_COUNTRIES')
        .onConflict('country_nm').ignore();
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
  } catch (err) {
    console.log('error: ', err);
    return;
  }
  const hub_countries = [];
  try {
    console.log('Hub_Counties: get all country names and convert to array');
    let q = knex.select('country_nm').from('rcubed.HUB_COUNTRIES');
    const result = await client.query(q.toQuery());
    const moreData = result.rows;
    // console.log('More data: ',moreData);
    moreData.forEach((country) => {
      hub_countries.push(country.country_nm);
    });

    const cntrs_to_delete = cntry_desc.filter((x) => hub_countries.indexOf(x) === -1);
    // console.log('countires to delete array: '+JSON.stringify(cntrs_to_delete));
    console.log(`cntrs_to_delete.length: ${cntrs_to_delete.length}`);
    console.log(`cntrs_to_delete: ${cntrs_to_delete.join()}`);
    if (cntrs_to_delete.length !== 0) {
      console.log('Hub_Countries: Delete counties not in Hub list');
      // const q1 = 'DELETE from rcubed.HUB_COUNTRIES where country_nm = $1';
      for (let i = 0; i < cntrs_to_delete.length; i += 1) {
        q = knex('rcubed.HUB_COUNTRIES')
          .where('country_nm', cntrs_to_delete[i])
          .del();
        // eslint-disable-next-line no-await-in-loop
        await client.query(q.toQuery());
      }
      console.log(`countries deleted ${cntrs_to_delete.join()}`);
    }
  } catch (err) {
    console.log('Error: ', err);
    return;
  } finally {
    client.end();
  }
  console.log('Hub Countries END');
};
