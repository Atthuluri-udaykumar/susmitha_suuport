module.exports = (sequelize, type) => {
    return sequelize.define('countries',{
    countries_id: {
        type: type.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
        country_nm: type.String
    })
}