// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getActiveProductTypes = async () => {
  console.log('Get Active Product Types');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.PRODUCT_TYPE')
    .where('IS_ACTIVE', true);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getAllProductType = async () => {
  console.log('get all product types');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.PRODUCT_TYPE');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.addProductType = async (product_type_nm, lilly_id) => {
  console.log('add product type');
  const q = knex
    .insert({ PRODUCT_TYPE_NM: product_type_nm }).into('rcubed.PRODUCT_TYPE');
  return createUpdate(lilly_id, q);
};

exports.updateProductType = async (product_type_id, product_type_nm, active, lilly_id) => {
  console.log(' update product type ');
  const isTrue = active === 'true';
  const q = knex('rcubed.PRODUCT_TYPE')
    .where('product_type_id', product_type_id)
    .update({
      product_type_nm,
      IS_ACTIVE: isTrue
    });
  return createUpdate(lilly_id, q);
};
