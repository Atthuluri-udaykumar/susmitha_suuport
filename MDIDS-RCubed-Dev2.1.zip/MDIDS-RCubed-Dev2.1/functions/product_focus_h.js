// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getAllProductFocus = async () => {
  console.log('Gt all product focus');
  const client = await createClient();
  await client.connect();
  const query = knex.select().from('rcubed.PRODUCT_FOCUS');
  const r = await client.query(query.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getActiveProductFocus = async () => {
  console.log('Get Active Product Focus');
  const client = await createClient();
  await client.connect();
  const query = knex.select('PRODUCT_FOCUS_ID', 'PRODUCT_FOCUS_NM')
    .from('rcubed.PRODUCT_FOCUS')
    .where('is_active', true);
  const r = await client.query(query.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getProductFocus = async (product_focus_id) => {
  console.log(`Get Product Focus: ${product_focus_id}`);
  const client = await createClient();
  await client.connect();
  const query = knex.select().from('rcubed.PRODUCT_FOCUS')
    .where('PRODUCT_FOCUS_ID', product_focus_id);
  const r = await client.query(query.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.addProductFocus = async (product_focus_nm, lilly_id) => {
  console.log(`Add product focus: ${product_focus_nm}`);
  const q = knex
    .insert({ product_focus_nm }).into('rcubed.PRODUCT_FOCUS');
  return createUpdate(lilly_id, q);
};

exports.updateProductFocus = async (product_focus_id, product_focus_nm, active, lilly_id) => {
  console.log(`Update product focus: ${product_focus_id}`);
  const isTrue = active === 'true';
  const q = knex('rcubed.PRODUCT_FOCUS')
    .where('product_focus_id', product_focus_id)
    .update({
      PRODUCT_FOCUS_NM: product_focus_nm,
      IS_ACTIVE: isTrue
    });
  return createUpdate(lilly_id, q);
};
