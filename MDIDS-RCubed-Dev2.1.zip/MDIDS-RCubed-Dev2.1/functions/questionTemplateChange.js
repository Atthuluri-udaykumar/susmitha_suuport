// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

exports.saveChangedQuestionTemplate = async (sub_id, req_type, req_question_type_id, req_qstn_txt,
  active, custom_allowed, lilly_id) => {
  console.log('Save Changed Question Template Start');
  console.log(`sub_id = ${sub_id} req_type = ${req_type} req_question_type_id = ${req_question_type_id} `
      + `active = ${active} custom_allowed = ${custom_allowed}, lilly_id= ${lilly_id}`);
  // const is_true = custom_allowed === 'true';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  const client = await createClient();
  await client.connect();

  let tmplt_chng_id_q;
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    const q = knex('rcubed.SUBMISSION_REQ_TMPLT_CHNG')
      .insert({
        SUBMISSION_REQ_TMPLT_ID: sub_id,
        REQ_TYPE: req_type,
        REQ_QUESTION_TYPE_LST_ID: req_question_type_id,
        CUSTOM_ALLOWED: custom_allowed
      }).returning('REQ_TMPLT_CHNG_ID');
    console.log(`query for Changed Question Template ${q.toQuery()}`);
    const r = await client.query(q.toQuery());
    // tmplt_chng_id = await data.query('insert into rcubed.SUBMISSION_REQ_TMPLT_CHNG ('
    //     + 'SUBMISSION_REQ_TMPLT_ID, REQ_TYPE, REQ_QUESTION_TYPE_LST_ID, CUSTOM_ALLOWED) '
    //     + 'VALUES(:sub_id, :req_type,:req_question_type_id,:custom_allowed)  '
    //     + ' returning REQ_TMPLT_CHNG_ID', {
    //   sub_id, req_type, req_question_type_id, custom_allowed: is_true, transactionId: transactionID
    // });

   // console.log(`r = ${JSON.stringify(r)}`);
    tmplt_chng_id_q = r.rows[0].req_tmplt_chng_id;
    console.log(`tmplt_chng_id_q = ${tmplt_chng_id_q}`);
    if (req_qstn_txt != null) {
      if (tmplt_chng_id_q > 0) {
        const d = JSON.parse(req_qstn_txt);
        let q2;
        for (let i = 0; i < d.data.qstn_txt.length; i += 1) {
          const txt = d.data.qstn_txt[i].Text;
          console.log(`REQ_QSTN_TXT.text =${txt}`);
          q2 = knex('rcubed.REQ_QSTN_LST_TXT_CHNG')
            .insert({
              REQ_TMPLT_CHNG_ID: tmplt_chng_id_q,
              REQ_QSTN_TXT: txt
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q2.toQuery());
        // data.query('insert into rcubed.REQ_QSTN_LST_TXT_CHNG ('
        //     + 'REQ_TMPLT_CHNG_ID, REQ_QSTN_TXT) VALUES(:sub_id, :text)',
        // { sub_id: tmplt_chng_id_q, text: txt, transactionId: transactionID });
        }
        console.log('Save Changed Question Template Submission type');
        for (let i = 0; i < d.data.SUBMISSION_TYPE.length; i += 1) {
          const id = d.data.SUBMISSION_TYPE[i].SUB_TYP_ID;
          q2 = knex('rcubed.SUB_REQ_SUB_TYP_CHNG_REF')
            .insert({
              REQ_TMPLT_CHNG_ID: tmplt_chng_id_q,
              SUB_TYP_ID: id
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q2.toQuery());
          // await data.query('insert into rcubed.SUB_REQ_SUB_TYP_CHNG_REF('
          //     + 'REQ_TMPLT_CHNG_ID, SUB_TYP_ID) VALUES(:tmplt_chng_id, :id)',
          // { tmplt_chng_id: tmplt_chng_id_q, id, transactionId: transactionID });
        }
        console.log('insert PRODUCT_TYPE');
        for (let i = 0; i < d.data.PRODUCT_TYPE.length; i += 1) {
          const id = d.data.PRODUCT_TYPE[i].PRODUCT_TYPE_ID;
          q2 = knex('rcubed.SUB_REQ_PRODUCT_TYP_CHNG_REF')
            .insert({
              REQ_TMPLT_CHNG_ID: tmplt_chng_id_q,
              PRODUCT_TYPE_ID: id
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q2.toQuery());
          // await data.query('insert into rcubed.SUB_REQ_PRODUCT_TYP_CHNG_REF ('
          //     + 'REQ_TMPLT_CHNG_ID, PRODUCT_TYPE_ID) VALUES(:tmplt_chng_id, :id)',
          // { tmplt_chng_id: tmplt_chng_id_q, id, transactionalId: transactionID });
        }
        console.log('insert REQ_CAT_LST');
        for (let i = 0; i < d.data.REQ_CAT_LST.length; i += 1) {
          const id = d.data.REQ_CAT_LST[i].REQ_CAT_LST_ID;
          q2 = knex('rcubed.SUB_REQ_REQ_CAT_CHNG_REF')
            .insert({
              REQ_TMPLT_CHNG_ID: tmplt_chng_id_q,
              req_cat_lst_id: id
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q2.toQuery());
          // await data.query('insert into rcubed.SUB_REQ_REQ_CAT_CHNG_REF ('
          //     + 'REQ_TMPLT_CHNG_ID, REQ_CAT_LST_ID) VALUES(:tmplt_chng_id, :id)',
          // { tmplt_chng_id: tmplt_chng_id_q, id, transactionalId: transactionID });
        }

        console.log('insert DOSSIER_LST');
        for (let i = 0; i < d.data.DOSSIER_LST.length; i += 1) {
          const id = d.data.DOSSIER_LST[i].DOSSIER_LST_ID;
          q2 = knex('rcubed.SUB_REQ_DOSSIER_CHNG_REF')
            .insert({
              REQ_TMPLT_CHNG_ID: tmplt_chng_id_q,
              DOSSIER_LST_ID: id
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q2.toQuery());
          // await data.query('insert into rcubed.SUB_REQ_DOSSIER_CHNG_REF ('
          //     + 'REQ_TMPLT_CHNG_ID, DOSSIER_LST_ID) VALUES(:tmplt_chng_id, :id)',
          // { tmplt_chng_id: tmplt_chng_id_q, id, transactionalId: transactionID });
        }
        console.log('insert GEN_REQ_CAT_LST');
        for (let i = 0; i < d.data.GEN_REQ_CAT_LST.length; i += 1) {
          const id = d.data.GEN_REQ_CAT_LST[i].GEN_REQ_CAT_LST_ID;
          q2 = knex('rcubed.SUB_REQ_GEN_REQ_CAT_CHNG_REF')
            .insert({
              REQ_TMPLT_CHNG_ID: tmplt_chng_id_q,
              GEN_REQ_CAT_LST_ID: id
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q2.toQuery());
          // await data.query('insert into rcubed.SUB_REQ_GEN_REQ_CAT_CHNG_REF ('
          //     + 'REQ_TMPLT_CHNG_ID, GEN_REQ_CAT_LST_ID) VALUES(:tmplt_chng_id, :id)',
          // { tmplt_chng_id: tmplt_chng_id_q, id, transactionalId: transactionID });
        }
      }
    }
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return tmplt_chng_id_q;
};
