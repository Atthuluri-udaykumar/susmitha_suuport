// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.getAllRegions = async () => {
  console.log('Get all regions');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.REGIONS');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getActiveRegions = async () => {
  console.log('Get active regions');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.REGIONS')
    .where('IS_ACTIVE', true);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getRegion = async (region_id) => {
  console.log('Get Region by ID');
  const client = await createClient();
  await client.connect();
  const q = knex.select().from('rcubed.REGIONS')
    .where('REGION_ID', region_id);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.addRegion = async (region_nm, lilly_id) => {
  console.log(`Add Region: ${region_nm}`);
  // eslint-disable-next-line no-param-reassign
  const q = knex
    .insert({
      REGION_NM: region_nm
    }).into('rcubed.REGIONS');
  return createUpdate(lilly_id, q);
};

exports.updateRegion = async (region_id, region_nm, active, lilly_id) => {
  console.log(`Update Region: ${region_nm}`);
  const isTrue = active === 'true';
  const q = knex('rcubed.REGIONS')
    .where('REGION_ID', region_id)
    .update({
      REGION_NM: region_nm,
      IS_ACTIVE: isTrue
    });
  return createUpdate(lilly_id, q);
};
