// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const reqCatList = require('../requirementCategoryList_h');

// ----------------------------------------------------------------------------//
// Define Middleware
// ----------------------------------------------------------------------------//

// Add CORS Middleware
/*  app.use((req,res,next) => {

      // Add default CORS headers for every request
      res.cors()

      // Call next to continue processing
      next()
  }) */

// Add Authorization Middleware
/* app.use((req,res,next) => {

    // Check for Authorization Bearer token
    if (req.auth.type === 'Bearer') {
        // Get the Bearer token value
        let token = req.auth.value
        // Set the token in the request scope
        req.token = token
        // Do some checking here to make sure it is valid (set an auth flag)
        req.auth = true
    }

    // Call next to continue processing
    next()
}) */

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getallrequirementcategorylist', async (req, res) => {
    console.log('Get all Requirement Category list router');
    let result;
    try {
      result = await reqCatList.getAllRequirementCatagoryList();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getactiverequirementcategorylist', async (req, res) => {
    console.log('Get active requirement category list router');
    let result;
    try {
      result = await reqCatList.getActiveRequirementList();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getrequirementcategeory', async (req, res) => {
    console.log('get requirement category router');
    let result;
    try {
      result = await reqCatList.getRequirementCategoryList(parseInt(req.query.req_cat_lst_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updaterequirementcategory', async (req, res) => {
    console.log('Update requirement category router');
    let result;
    try {
      result = await reqCatList.updateRequirementCategoryList(
        parseInt(req.query.req_cat_lst_id, 10),
        req.query.req_cat_lst_nm, req.query.active, req.query.lilly_id
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/addrequirementcategory', async (req, res) => {
    console.log('Add requirement category router');
    let result;
    try {
      result = await reqCatList.addRequirementCategory(req.query.req_cat_lst_nm,
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'POST,GET,OPTIONS'
      })
      .json(result);
  });
};
