const submissionform = require('../submissionForm_h');
const getsubmissionform = require('../getSubmissionForm_h');

module.exports = (app, opt) => {
  app.post('/savesubmissionform', async (req, res) => {
    console.log('save submission form router');
    let result;
    try {
      console.log(`formdata: ${req.body.formdata}`);
      result = await submissionform.saveSubmissionRequirementForm(req.body.formdata,
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getsubmissionform', async (req, res) => {
    console.log('get submission form');
    let result;
    let isTrue = false;
    let activeQuestions = true;
    if (Object.keys(req.query.is_current).length === 0) {
      isTrue = true;
    } else {
      isTrue = req.query.is_current === 'true';
    }
    if (Object.keys(req.query.active_questions).length === 0) {
      activeQuestions = false;
    } else {
      activeQuestions = req.query.is_current === 'true';
    }
    try {
      result = await getsubmissionform.getSubmissionForm(
        parseInt(req.query.sub_form_id, 10),
        isTrue,
        activeQuestions
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getallsubmissionformsshort', async (req, res) => {
    console.log('get all submission forms short');
    let result;
    try {
      result = await submissionform.getAllSubmissionFormsShort(
        parseInt(req.query.currentpage, 10)
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updatesubmissionform', async (req, res) => {
    console.log('update submission form route');
    let result;
    try {
      result = await submissionform.updateSubmissionForm(
        req.body.formdata,
        parseInt(req.query.SUB_REQ_FORMS_ID, 10), req.query.lilly_id
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/searchsubmissionforms', async (req, res) => {
    console.log('Search Submission Forms router');
    let isTrue = false;
    isTrue = req.query.is_current === 'true';
    const cpage = parseInt(req.query.currentpage, 10);
    console.log(`currentpage = ${cpage}`);
    // }
    console.log(`sub_typ_id = ${parseInt(req.query.sub_typ_id, 10)}`);
    let result;
    try {
      result = await submissionform.searchSubmissionForm(
        parseInt(req.query.sub_typ_id, 10),
        req.query.sub_req_forms_nm,
        req.body.formdata,
        isTrue,
        cpage
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/searchformnames', async (req, res) => {
    console.log('Search form names router start');
    let result;
    try {
      result = await submissionform.searchFormNames(
        parseInt(req.query.sub_typ_id, 10),
        parseInt(req.query.product_type, 10),
        parseInt(req.query.dossier_lst_id, 10)
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
