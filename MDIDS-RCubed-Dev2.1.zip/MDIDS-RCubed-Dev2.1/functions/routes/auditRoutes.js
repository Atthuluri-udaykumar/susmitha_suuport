const audit = require('../audit_h');

module.exports = (app, opt) => {
  app.get('/loggedactions', async (req, res) => {
    console.log('get audit table router start');
    let result;
    try {
      result = await audit.getAuditTable();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getauditrange', async (req, res) => {
    console.log('get audit range router start');
    let result;
    try {
      result = await audit.getAuditRange(req.query.startdate, req.query.enddate);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
