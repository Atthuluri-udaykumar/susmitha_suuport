// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed' ,logger: true })

const countryOwners = require('../country_owners_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getallcountryowners', async (req, res) => {
    console.log('get all country owners router');
    let result;
    try {
      result = await countryOwners.getAllCountiresOwners();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getcountriesforuser', async (req, res) => {
    console.log('get countries for user router ');
    let result;
    try {
      result = await countryOwners.GetCountriesForUser(parseInt(req.user_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getusersforcountry', async (req, res) => {
    console.log('get owners for country router');
    let result;
    try {
      result = await countryOwners.GetUserForCountry(parseInt(req.query.countries_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/createcountryowner', async (req, res) => {
    console.log('Create Country Owner router');
    let result;
    try {
      // eslint-disable-next-line max-len
      result = await countryOwners.CreateCountryOwner(parseInt(req.query.user_id, 10),
        parseInt(req.query.country_id, 10), req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

};
