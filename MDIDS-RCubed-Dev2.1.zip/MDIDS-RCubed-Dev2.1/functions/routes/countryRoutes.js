// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })
const countries = require('../country_h');
// import {allCountries, allActiveCountries} from '../country_h'


// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//

module.exports = (app, opt) => {
  app.get('/allcountries', async (req, res) => {
    console.log('All Countires router!!');
    let result;
    try {
      result = await countries.allCountries();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/allactivecountires', async (req, res) => {
    console.log(' All Active Counties router)');
    let result;
    try {
      result = await countries.allActiveCountries();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  // ?countryID=somenumber

  app.get('/getcountry', async (req, res) => {
    console.log('Get Country Router');
    let result;
    try {
      result = await countries.getCountry(parseInt(req.query.country_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
    // return result;
  });

  app.get('/allcountriesinregion', async (req, res) => {
    console.log('Get all counties in region router');
    let result;
    try {
      result = await countries.getAllCountriesInRegion(parseInt(req.query.region_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updatecountryregion', async (req, res) => {
    console.log('Update country region');
    let result;
    try {
      result = await countries.updateCountryRegion(req.query.active,
        parseInt(req.query.region_id, 10),
        parseInt(req.query.country_id, 10),
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/countrieswithoutregion', async (req, res) => {
    console.log('Get countries without regions router');
    let result;
    try {
      result = await countries.getAllCountriesWithoutRegion();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
