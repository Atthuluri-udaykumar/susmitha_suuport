// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const dosageFormList = require('../dosageFormList_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getalldosageforms', async (req, res) => {
    console.log('get all dosage forms router');
    let result;
    try {
      result = await dosageFormList.getAllDosageForms();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }

    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getactivedosageforms', async (req, res) => {
    console.log('Get active dosage forms router');
    let result;
    try {
      result = await dosageFormList.getActiveDosageForms();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getdosageform', async (req, res) => {
    console.log('Get doage form router');
    let result;
    try {
      result = await dosageFormList.getDosageForm(parseInt(req.query.dosage_frm_lst_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updatedosageform', async (req, res) => {
    console.log('Update dosage form router');
    let result;
    try {
      result = await dosageFormList.updateDosageForm(parseInt(req.query.dosage_frm_lst_id, 10),
        req.query.dosage_frm_lst_nm, req.query.active, req.query.lillt_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/adddosageform', async (req, res) => {
    console.log('Add dosage form list route');
    let result;
    try {
      result = await dosageFormList.addDosageForm(req.query.dosage_frm_lst_nm,
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'POST,OPTIONS'
      })
      .json(result);
  });

  app.get('/getactivedosageforms2', async (req, res) => {
    console.log('Get active dosage forms router');
    let result;
    try {
      result = await dosageFormList.getActiveDossageForms2();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
