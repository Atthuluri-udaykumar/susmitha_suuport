// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const dossierList = require('../dossier_lst_h');


// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
/*    app.get('/getalldossierlist1', async (req, res) => {
        console.log('Get all dossier list recursion router')
        let result;
        try {
            result = await dossierList.getAllDossierList1();
        }catch(err){
            res.error(err.name+' '+err.message);
        }
        res.status(200)
            .cors({
                methods: 'OPTIONS,POST,GET'
            })
            .json(result);
    }); */

  app.get('/getalldossierlist2', async (req, res) => {
    console.log('Get all dossier list Ltree router');
    let result;
    try {
      result = await dossierList.getAllDossierList2();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/adddossierlistnode', async (req, res) => {
    console.log('Add a dossier list node route');
    let result;
    try {
      result = await dossierList.addDossierToList(parseInt(req.query.parent_id, 10),
        req.query.name, req.query.active,req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST'
      })
      .json(result);
  });

  app.post('/updateDossiernode', async (req, res) => {
    console.log('Update dossier node route');
    let result;
    try {
      result = await dossierList.updateDossierListNode(parseInt(req.query.parent_id, 10),
        req.query.dossier_lst_nm,
        req.query.active, parseInt(req.query.dossier_lst_id, 10),req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'POST,GET,OPTIONS'
      })
      .json(result);
  });
};
