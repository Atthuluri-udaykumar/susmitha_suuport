// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const gen_req_cat_lst = require('../generalRequirementCategoryList_h');

// ----------------------------------------------------------------------------//
// Define Middleware
// ----------------------------------------------------------------------------//

// Add CORS Middleware
/*  app.use((req,res,next) => {

      // Add default CORS headers for every request
      res.cors()

      // Call next to continue processing
      next()
  }) */

// Add Authorization Middleware
/* app.use((req,res,next) => {

    // Check for Authorization Bearer token
    if (req.auth.type === 'Bearer') {
        // Get the Bearer token value
        let token = req.auth.value
        // Set the token in the request scope
        req.token = token
        // Do some checking here to make sure it is valid (set an auth flag)
        req.auth = true
    }

    // Call next to continue processing
    next()
}) */

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getallgeneralrequirementcategorylist', async (req, res) => {
    console.log('Get all general requirement category list router');
    let result;
    try {
      result = await gen_req_cat_lst.getAllGeneralRequirementCategoryList();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getactivegeneralrequirementcategorylist', async (req, res) => {
    console.log('Get active general requirement category list router');
    let result;
    try {
      result = await gen_req_cat_lst.getActiveGeneralRequirementCategoryList();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getgeneralrequirementcategory', async (req, res) => {
    console.log('Get general requirement category router');
    let result;
    try {
      result = await gen_req_cat_lst.getGeneralRequirementCategory(
        parseInt(req.query.gen_req_cat_lst_id, 10)
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updategeneralrequirementcategory', async (req, res) => {
    console.log('Update general requirement category router');
    let result;
    try {
      result = await gen_req_cat_lst.updateGeneralRequirementCategory(
        parseInt(req.query.gen_req_cat_lst_id, 10),
        req.query.gen_req_cat_lst_nm, req.query.active, req.query.lilly_id
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/addgeneralrequirementcategory', async (req, res) => {
    console.log('Add general requirement category router');
    let result;
    try {
      result = await gen_req_cat_lst.addGeneralRequirementCategory(req.query.gen_req_cat_lst_nm,
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
