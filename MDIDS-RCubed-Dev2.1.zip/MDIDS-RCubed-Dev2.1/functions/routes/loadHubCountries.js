const hc = require('../hub_country_service');

module.exports = (app, opt) => {
  app.get('/loadcountries', async (req, res) => {
    console.log('load hub countries router');
    try {
      await hc.HubCountry();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      });
  });
};
