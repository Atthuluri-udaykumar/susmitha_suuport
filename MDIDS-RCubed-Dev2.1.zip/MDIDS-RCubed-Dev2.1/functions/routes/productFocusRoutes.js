// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed', logger: true})

const productFocus = require('../product_focus_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getallproductfocus', async (req, res) => {
    console.log('Get all Product Focus router');
    let result;
    try {
      result = await productFocus.getAllProductFocus();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.header('Access-Control-Allow-Origin', '*')
      .header('Access-Control-Allow-Methods', 'GET, OPTIONS')
      .status(200)
      .header('Access-Control-Allow-Headers', '*')
      .json(result);
  });

  app.get('/getactiveproductfocus', async (req, res) => {
    console.log('Get active product focus router');
    let result;
    try {
      result = await productFocus.getActiveProductFocus();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getproductfocus', async (req, res) => {
    console.log(`Get product focus: ${req.product_focus_id}`);
    let result;
    try {
      result = await productFocus.getProductFocus(parseInt(req.query.product_focus_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/addproductfocus', async (req, res) => {
    console.log('Add product focus router');
    let result;
    try {
      result = await productFocus.addProductFocus(req.query.product_focus_nm,req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updateproductfocus', async (req, res) => {
    console.log('Update product focus router');
    let result;
    try {
      result = await productFocus.updateProductFocus(parseInt(req.query.product_focus_id, 10),
        req.query.product_focus_nm, req.query.active, req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.header('Access-Control-Allow-Origin', '*')
      .header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
      .status(200)
      .header('Access-Control-Allow-Headers', '*')
      .json(result);
  });
};
