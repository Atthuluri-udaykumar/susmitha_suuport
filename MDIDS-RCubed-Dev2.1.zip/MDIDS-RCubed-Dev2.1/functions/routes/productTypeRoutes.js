// Require and init API router module
// const app = require('lambda-api')({ base: 'rcubed', logger: true })
// app.routes(true)
const productType = require('../productType_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//

module.exports = (app, opt) => {
  app.get('/getallactiveproducttype', async (req, res) => {
    console.log('Get all active product type router');
    let result;
    try {
      result = await productType.getActiveProductTypes();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getallproducttype', async (req, res) => {
    console.log('Get all Product Type router');
    let result;
    try {
      result = await productType.getAllProductType();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  // assumes active=Y

  app.post('/addproducttype', async (req, res) => {
    console.log('Add product type router');
    let result;
    try {
      result = await productType.addProductType(req.query.product_type_nm, req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updateproducttype', async (req, res) => {
    console.log('Update product type router');
    let result;
    try {
      result = await productType.updateProductType(parseInt(req.query.product_type_id, 10),
        req.query.product_type_nm, req.query.active, req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
