// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const regions = require('../regions_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getallregions', async (req, res) => {
    console.log('get all regions router');
    let result;
    try {
      result = await regions.getAllRegions();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getactiveregions', async (req, res) => {
    console.log('get active regions router');
    let result;
    try {
      result = await regions.getActiveRegions();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getregion', async (req, res) => {
    console.log('Get Region router');
    let result;
    try {
      result = await regions.getRegion(parseInt(req.query.region_id));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/addregion', async (req, res) => {
    console.log('Add region router');
    let result;
    try {
      result = await regions.addRegion(decodeURIComponent(req.query.region_nm), req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updateregion', async (req, res) => {
    console.log('Update region router');
    let result;
    try {
      result = await regions.updateRegion(parseInt(req.query.region_id, 10),
        decodeURIComponent(req.query.region_nm),
        req.query.active, req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
