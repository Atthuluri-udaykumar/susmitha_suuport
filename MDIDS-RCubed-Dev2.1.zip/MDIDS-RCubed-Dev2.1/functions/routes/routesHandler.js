// Require and init API router module
const app = require('lambda-api')({ base: 'rcubed', logger: true });

app.register(require('./subReqTemplateRoutes'), { prefix: '/subreqtemplate' });
app.register(require('./productTypeRoutes'), { prefix: '/producttype' });
app.register(require('./countryRoutes'), { prefix: '/countries' });
app.register(require('./userRoutes'), { prefix: '/users' });
app.register(require('./productFocusRoutes'), { prefix: '/productfocus' });
app.register(require('./countryOwnersRoutes'), { prefix: '/countryowner' });
app.register(require('./regionsRoutes'), { prefix: '/regions' });
app.register(require('./dosageFormListRoutes'), { prefix: '/dosageformlist' });
app.register(require('./RequirementCategoryListRoutes'), { prefix: '/requirementcategorylist' });
app.register(require('./generalRequirementCategoryListRoutes'), { prefix: '/generalrequirementcategorylist' });
app.register(require('./submissionTypeRoutes'), { prefix: '/submissiontype' });
app.register(require('./dossierListRoutes'), { prefix: '/dossierlist' });
app.register(require('./SubmissionFormRoutes'), { prefix: '/submissionform' });
app.register(require('./taskRoutes'), { prefix: '/task' });
app.register(require('./auditRoutes'), { prefix: '/audit' });
app.register(require('./loadHubCountries'), { prefix: '/hubcountries' });

const errorHandler = (err, req, res, next) => {
  console.log(`Error: ${JSON.stringify(err)}`);
  if (err.name === 'RouteError') {
    res.status(500)
      .header('Access-Control-Allow-Origin', '*')
      .header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
      .header('Access-Control-Allow-Headers', '*')
      .json(err);
  } else if (err.name === 'FileError') {
    res.status(500)
      .header('Access-Control-Allow-Origin', '*')
      .header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
      .header('Access-Control-Allow-Headers', '*')
      .json(err);
  } else if (err.name === 'MethodError') {
    res.status(500)
      .header('Access-Control-Allow-Origin', '*')
      .header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
      .header('Access-Control-Allow-Headers', '*')
      .json(err);
  } else if (err.name === 'ResponseError') {
    res.status(500)
      .header('Access-Control-Allow-Origin', '*')
      .header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
      .header('Access-Control-Allow-Headers', '*')
      .json(err);
  }
  // continue
  next();
};

app.use((err, req, res, next) => {
  errorHandler(err, req, res, next);
  next();
});

// ----------------------------------------------------------------------------//
// Main router handler
// ----------------------------------------------------------------------------//
exports.Router = async (event, context, callback) => {
  console.log('Router start');
  // app.routes(true);
  // !!!IMPORTANT: Set this flag to false, otherwise the lambda function
  // won't quit until all DB connections are closed, which is not good
  // if you want to freeze and reuse these connections
  context.callbackWaitsForEmptyEventLoop = false;
  // app.routes(true)

  // Run the request
  return app.run(event, context, callback);
}; // end router handler
