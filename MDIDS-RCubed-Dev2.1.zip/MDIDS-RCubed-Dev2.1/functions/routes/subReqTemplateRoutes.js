// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const submissionReq = require('../submissionRequirementTemplate');
const getsubreqtemplate = require('../getSubmissionRequirementTemplate');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getreqquestiontypelist', async (req, res) => {
    console.log('Get requirement question type list router');
    let result;
    try {
      result = await submissionReq.getRequiremntQstnTypeLst();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/savesubmissionrequirementtemplate', async (req, res) => {
    console.log('Save submission requirement template route');
    let result;
    let req_qstn_txt;
    // if(Object.keys(req.body.req_qstn_txt).length === 0){
    if (req.body.req_qstn_txt === 0) {
      req_qstn_txt = 0;
    } else {
      req_qstn_txt = req.body.req_qstn_txt;
    }
    try {
      result = await submissionReq.saveSubmissionRequirementTemplate(req.query.req_typ,
        parseInt(req.query.req_question_type_id, 10), req_qstn_txt, req.query.custom_allowed,
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updatesubmissionrequirementtemplate', async (req, res) => {
    console.log('Update Submission requirement template route');
    let result;
    const sendNotification = req.query.sendNotification === 'true';

    console.log(`Send notification after if = ${sendNotification}`);
    try {
      result = await submissionReq.updateSubmissionRequirementTemplate(
        parseInt(req.query.sub_id, 10),
        req.query.req_type,
        parseInt(req.query.req_question_type_id, 10),
        req.body.req_qstn_txt, req.query.active, req.query.custom_allowed,
        sendNotification, req.query.lilly_id
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getsubmissionrequirementtemplate', async (req, res) => {
    console.log(`Get submission Requirement template: ${req.query.sub_id}`);
    let result;
    try {
      result = await getsubreqtemplate.getSubmissionRequirementTemplate(
        parseInt(req.query.sub_id, 10),
        true
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getallactivesubmissionrequirementtemplateshort', async (req, res) => {
    console.log('Get all submission requirement templates short router');
    let result;

    try {
      result = await submissionReq.getAllSubmissionRequirementTemplateShort();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getallsubmissionrequirementtemplates', async (req, res) => {
    console.log('Get all submission requirement templates full');
    let isTrue = false;
    if (Object.keys(req.query.allActive).length === 0) isTrue = true;
    let result;
    try {
      result = await submissionReq.getAllSubmissionReqTemplate(isTrue);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/searchsubmissionreqtemplates', async (req, res) => {
    console.log('Search submission requirement template router');
    // if (Object.keys(req.query.currentpage).length === 0) {
    //   cpage = 0;
    // } else {
    const cpage = req.query.currentpage;
    let result;
    try {
      result = await submissionReq.searchSubmissionReqTemplates(req.query.req_typ,
        req.body.data, cpage);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/istemplateedited', async (req, res) => {
    console.log('Is template edited route start');
    let result;
    try {
      result = await submissionReq.isTemplateEdited(parseInt(req.query.sub_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/isquestioninaform', async (req, res) => {
    console.log('Is question in a form route start');
    let result;
    try {
      result = await submissionReq.isQuestionInForm(parseInt(req.query.sub_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/isduplicatequestion', async (req, res) => {
    console.log(`Is question name duplicate start for ${req.query.req_type}`);
    let result;
    try {
      result = await submissionReq.isQuestionNameDuplicate(req.query.req_type);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
