// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const submissionType = require('../submissionType_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/getallsubmissiontypes', async (req, res) => {
    console.log('Get all submission types router');
    let result;
    try {
      result = await submissionType.getAllSubmissionTypes();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getactivesubmissiontypes', async (req, res) => {
    console.log('Get active submission types router');
    let result;
    try {
      result = await submissionType.getActiveSubmissionTypes();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getsubmissiontype', async (req, res) => {
    console.log('get submission type router');
    let result;
    try {
      result = await submissionType.getSubmissionType(parseInt(req.query.sub_typ_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updatesubmissiontype', async (req, res) => {
    console.log('Update submission type router');
    let result;
    try {
      result = await submissionType.updateSubmissionType(
        parseInt(req.query.sub_typ_id, 10),
        req.query.sub_typ_nm, req.query.active, req.query.lilly_id
      );
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/addsubmissiontype', async (req, res) => {
    console.log('Add submission type route');
    let result;
    try {
      result = await submissionType.addSubmissionType(req.query.sub_typ_nm,
        req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'POST,OPTIONS'
      })
      .json(result);
  });
};
