const taskmgr = require('../task_manager');

module.exports = (app, opt) => {
  app.get('/completetask', async (req, res) => {
    console.log('complete task router start');
    let result;
    try {
      result = await taskmgr.completeFormReviewTask(parseInt(req.query.task_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/gettasksforuser', async (req, res) => {
    console.log('get task for user router start');
    let result;
    try {
      result = await taskmgr.getTasksForUser(req.query.lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/accepttask', async (req, res) => {
    console.log('Accept task router start');
    let result;
    try {
      result = await taskmgr.acceptTask(req.query.lilly_id,
        parseInt(req.query.task_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/assigntask', async (req, res) => {
    console.log('Assign task router start');
    let result;
    try {
      result = await taskmgr.assignTask(req.query.lilly_id,
        parseInt(req.query.task_id, 10),
        req.query.due_date);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/updatetaskdetails', async (req, res) => {
    console.log('update task details router start');
    let result;
    try {
      result = await taskmgr.updateTaskDetails(parseInt(req.query.task_id, 10),
        req.query.details);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getactivetasks', async (req, res) => {
    console.log('Get active task router start');
    let result;
    try {
      result = await taskmgr.getActiveTasks();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getunassignedtasks', async (req, res) => {
    console.log('get unassigned task router start');
    let result;
    try {
      result = await taskmgr.getUnassignedTasks();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/gettask', async (req, res) => {
    console.log('get task route start');
    let result;
    try {
      result = await taskmgr.getTask(parseInt(req.query.task_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/rejecttask', async (req, res) => {
    console.log('reject task router start');
    let result;
    try {
      result = await taskmgr.rejectTask(parseInt(req.query.task_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/taskreviewed', async (req, res) => {
    console.log('task reviewed router start');
    let result;
    try {
      result = await taskmgr.isReviewed(parseInt(req.query.task_id, 10),
        parseInt(req.query.sub_form_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/taskreviewed', async (req, res) => {
    console.log('task reviewed router start');
    let result;
    try {
      result = await taskmgr.isReviewed(parseInt(req.query.task_id, 10),
        parseInt(req.query.sub_form_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
