// Require and init API router module
// const app = require('lambda-api')({  base: 'rcubed',logger: true })

const users = require('../users_h');

// ----------------------------------------------------------------------------//
// Build API routes
// ----------------------------------------------------------------------------//
module.exports = (app, opt) => {
  app.get('/listallusers', async (req, res) => {
    console.log('list all users router');
    let result;
    try {
      result = await users.listAllUsers();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getallactiveusers', async (req, res) => {
    console.log('list all active users');
    let result;
    try {
      result = await users.listActiveUsers();
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/getuser', async (req, res) => {
    console.log('get user router');
    let result;
    try {
      result = await users.getUser(parseInt(req.query.user_id, 10));
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.post('/userdata', async (req, res) => {
    console.log('User Data router start');
    let result;
    try {
      result = await users.userData(req.body.user);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });

  app.get('/deleteuser', async (req, res) => {
    console.log('soft delete user route start');
    let result;
    try {
      result = await users.deleteUser(req.query.lilly_id, req.query.admin_lilly_id);
    } catch (err) {
      res.error(`${err.name} ${err.message}`);
    }
    res.status(200)
      .cors({
        methods: 'OPTIONS,POST,GET'
      })
      .json(result);
  });
};
