const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});

exports.queryTest = async (sub_form_id) => {
  console.log('Lets see what the query looks like...');
  const q = knex.from(knex.raw('??(??,??,??,??,??,??,??'), ['rcubed.SUB_REQ_FORMS_DRAFT_QSTN_LST',
    'SUB_REQ_FORMS_ID', 'SUBMISSION_REQ_TMPLT_ID', 'SUB_REQ_FORM_QSTN_NMBR', 'QSTN_LOGIC',
    'PARENT_ID', 'IS_ACTIVE']).returning('SUB_REQ_FORMS_QSTN_LST_ID')
    .insert(function () {
      this.from('rcubed.SUB_REQ_FORMS_QSTN_LST AS ql')
        .where('SUB_REQ_FORMS_QSTN_LST_ID', sub_form_id)
        .select('ql.SUB_REQ_FORMS_ID', 'ql.SUBMISSION_REQ_TMPLT_ID',
          'ql.SUB_REQ_FORM_QSTN_NMBR', 'ql.QSTN_LOGIC', 'ql.PARENT_ID',
          false);
    });

  console.log(`query = ${q.toQuery()}`);
  return q.toQuery();
};
