// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const { Client } = require('pg');
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function markChangeSubmissionForm(formList, tmplt_chng_id, sub_id) {
  console.log('Mark submission form change');
  let chng_form_qstn_lst_id;
  const client = await createClient();
  await client.connect();
  console.log(`mark form change result = ${JSON.stringify(formList)}`);
  try {
    for (let i = 0; i < formList.records.length; i += 1) {
      const sub_form_id = parseInt(formList.records[i].sub_req_forms_id, 10);
      console.log(`sub_form_id = ${sub_form_id}`);
      let q = knex('rcubed.SUB_REQ_FORMS')
        .update({
          HAS_CHANGED: true
        })
        .where('SUB_REQ_FORMS_ID', sub_form_id);
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
      let value = [sub_form_id];
      q = 'insert into rcubed.SUB_REQ_FORMS_DRAFT (SUB_REQ_FORMS_ID,SUB_TYP_ID,'
          + 'sub_req_forms_nm) select sf.SUB_REQ_FORMS_ID, sf.SUB_TYP_ID,'
          + 'sf.sub_req_forms_nm from rcubed.SUB_REQ_FORMS as sf '
          + 'where sf.SUB_REQ_FORMS_ID = ? '
          + 'returning SUB_REQ_FORMS_DRAFT_ID';
      // eslint-disable-next-line no-await-in-loop
      const draft_form_id = await client.query(q, value);

      q = 'insert into rcubed.SUB_REQ_FORMS_DRAFT_QSTN_LST(SUB_REQ_FORMS_ID,sub_req_forms_qstn_lst_id,'
          + 'SUBMISSION_REQ_TMPLT_ID,'
      + 'SUB_REQ_FORM_QSTN_NMBR,QSTN_LOGIC,PARENT_ID,is_active,sub_req_forms_draft_id ) select ql.SUB_REQ_FORMS_ID,'
      + 'ql.sub_req_forms_qstn_lst_id, ql.SUBMISSION_REQ_TMPLT_ID, ql.SUB_REQ_FORM_QSTN_NMBR,'
      + ' ql.QSTN_LOGIC, ql.PARENT_ID, false,? from'
      + ' rcubed.SUB_REQ_FORMS_QSTN_LST as ql where SUB_REQ_FORMS_ID = ? '
      + 'returning SUB_REQ_FORMS_QSTN_DRFT_LST_ID';
      value = [draft_form_id, sub_form_id];

      // eslint-disable-next-line no-await-in-loop
      chng_form_qstn_lst_id = await client.query(q, value);

      // console.log(`draft question id =${chng_form_qstn_lst_id}`);
      //todo update the draft question with the new question data
      q = 'update rcubed.SUB_REQ_FORMS_DRAFT_QSTN_LST '
      + 'SET ';
      /* q = knex('rcubed.SUB_REQ_FORMS_DRAFT_QSTN_LST')
        .update({
          SUBMISSION_REQ_TMPLT_ID: tmplt_chng_id,
          SUB_REQ_FORMS_QSTN_LST_ID: chng_form_qstn_lst_id,
          SUB_REQ_FORMS_ID: sub_id
        }); */
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
  } catch (err) {
    console.log(`Error in Mark Change Submission form ${err}`);
  } finally {
    client.end();
  }
  return chng_form_qstn_lst_id;
}

exports.getChangedSubmissionForms = async (sub_tmpl_id, tmplt_chng_id) => {
  console.log('Submission form change - get Changed forms');
  const client = await createClient();
  await client.connect();
  const result = {};

  try {
    /* const q = knex.select('ql.SUB_REQ_FORMS_ID')
      .from({ ql: 'rcubed.SUB_REQ_FORMS_QSTN_LST' })
      .join({ f: 'rcubed.SUB_REQ_FORMS' }, 'f.SUB_REQ_FORMS_ID', '=',
        'ql.SUB_REQ_FORMS_ID')
      .where('ql.SUBMISSION_REQ_TMPLT_ID', sub_tmpl_id)
      .where('ql.IS_ACTIVE', true); */
    const q = knex.distinct('SUB_REQ_FORMS_ID')
      .from('rcubed.SUB_REQ_FORMS_QSTN_LST')
      .where('SUBMISSION_REQ_TMPLT_ID', sub_tmpl_id);
    console.log(`query = ${q.toQuery()}`);
    const r = await client.query(q.toQuery());
    result.records = r.rows;
  } catch (err) {
    console.log(`Error in getting Submission forms with changed question ${err}`);
    return err;
  } finally {
    client.end();
  }
  if (result.records.length > 0) {
    await markChangeSubmissionForm(result, tmplt_chng_id, sub_tmpl_id);
  }
  return result;
};
