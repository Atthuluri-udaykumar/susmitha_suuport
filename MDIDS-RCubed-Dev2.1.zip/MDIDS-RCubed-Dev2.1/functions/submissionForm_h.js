// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const { Client } = require('pg');
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

/* {
    "records": {
    "SUB_REQ_FORMS":{
        "SUB_REQ_FORMS_ID": 0,
        "SUB_TYP_ID": 2,
        "sub_req_forms_nm": "some name1",
            "IS_ACTIVE": true
    },
    "PRODUCT_TYPE": [
        {
            "PRODUCT_TYPE_ID": 1,
            "OPERATOR": "AND"
        },
        {
            "PRODUCT_TYPE_ID": 2,
            "OPERATOR": "OR"
        }

    ],
        "DOSSIER_REF": [
        {
            "DOSSIER_LST_ID": 176,
            "OPERATOR": "AND"
        },
        {
            "DOSSIER_LST_ID": 177,
            "OPERATOR": "AND"
        }
    ],
        "FORMS_QSTN_LST": [
        {
            "SUB_REQ_FORMS_QSTN_LST_ID": 1,
            "SUBMISSION_REQ_TMPLT_ID": 2,
            "SUB_REQ_FORM_QSTN_NMBR": 1,
            "SUB_REQ_FORMS_ID": 0,
            "QSTN_LOGIC": "if yes goto 3",
            "PARENT_ID": 0, // zero for null or root
            "IS_ACTIVE": true

        },
        {
            "SUB_REQ_FORMS_QSTN_LST_ID": 2,
            "SUBMISSION_REQ_TMPLT_ID": 3,
            "SUB_REQ_FORM_QSTN_NMBR": 2,
            "SUB_REQ_FORMS_ID": 0,
            "QSTN_LOGIC": "",
            "PARENT_ID": 1,// based on SUB_REQ_FORM_QSTN_NMBR
            "IS_ACTIVE": true

        },
        {
            "SUB_REQ_FORMS_QSTN_LST_ID": 1,
            "SUBMISSION_REQ_TMPLT_ID": 4,
            "SUB_REQ_FORM_QSTN_NMBR": 1,
            "SUB_REQ_FORMS_ID": 0,
            "QSTN_LOGIC": "",
            "PARENT_ID": 0, // zero for null or root
            "IS_ACTIVE": true

        }
    ]
}
}  */
async function getSubmissionForm(SUB_REQ_FORMS_ID) {
  const client = await createClient();
  await client.connect();
  const q = knex.select('sf.SUB_REQ_FORMS_ID', 'sf.SUB_TYP_ID',
    'st.SUB_TYP_NM', 'sf.sub_req_forms_nm', 'sf.IS_ACTIVE')
    .from({ sf: 'rcubed.SUB_REQ_FORMS' })
    .leftOuterJoin({ st: 'rcubed.SUBMISSION_TYPE' }, 'sf.SUB_TYP_ID', '=',
      'st.SUB_TYP_ID')
    .where('sf.SUB_REQ_FORMS_ID', SUB_REQ_FORMS_ID)
    .orderBy('sf.SUB_TYP_ID');
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows[0];
  client.end();
  return result;
}

exports.saveSubmissionRequirementForm = async (formData, lilly_id) => {
  console.log('save Submission Requirment form');
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  const client = await createClient();
  await client.connect();
  const d = JSON.parse(formData);
  const sub_id = d.records.SUB_REQ_FORMS.SUB_TYP_ID;
  const { sub_req_forms_nm } = d.records.SUB_REQ_FORMS;
  console.log(`sub_id: ${sub_id}`);
  const sub_f_record = {};
  let SUB_REQ_FORMS_ID;
  try {
    console.log('save SUB_REQ_FORMS');
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    let q1 = knex.returning('SUB_REQ_FORMS_ID')
      .insert({
        SUB_TYP_ID: sub_id,
        sub_req_forms_nm
      }).into('rcubed.SUB_REQ_FORMS');
    const r = await client.query(q1.toQuery());
    sub_f_record.records = r.rows;
    // const sub_form_r = JSON.stringify(sub_f_record);
    SUB_REQ_FORMS_ID = sub_f_record.records[0].sub_req_forms_id;
    console.log(`SUB_REQ_FORMS_ID: ${SUB_REQ_FORMS_ID}`);

    console.log('save SUB_REQ_FORMS_product_type_ref');

    for (let i = 0; i < d.records.PRODUCT_TYPE.length; i += 1) {
      const { PRODUCT_TYPE_ID } = d.records.PRODUCT_TYPE[i];
      q1 = knex.insert({
        SUB_REQ_FORMS_ID,
        PRODUCT_TYPE_ID
      }).into('rcubed.SUB_REQ_FORMS_PRODUCT_TYPE_REF');
      console.log(`Product type id: ${PRODUCT_TYPE_ID}`);
      // eslint-disable-next-line no-await-in-loop
      await client.query(q1.toQuery());
    }

    console.log('save SUB_REQ_FORMS_dossier_ref');
    for (let i = 0; i < d.records.DOSSIER_REF.length; i += 1) {
      const { DOSSIER_LST_ID } = d.records.DOSSIER_REF[i];
      q1 = knex.insert({
        SUB_REQ_FORMS_ID,
        DOSSIER_LST_ID
      }).into('rcubed.SUB_REQ_FORMS_DOSSIER_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q1.toQuery());
    }

    console.log('save SUB_REQ_FORMS_forms_qstn_lst');

    for (let i = 0; i < d.records.FORMS_QSTN_LST.length; i += 1) {
      const { SUBMISSION_REQ_TMPLT_ID } = d.records.FORMS_QSTN_LST[i];
      const { SUB_REQ_FORM_QSTN_NMBR } = d.records.FORMS_QSTN_LST[i];
      const parentID = d.records.FORMS_QSTN_LST[i].PARENT_ID;
      console.log(`parent_id: ${parentID}`);
      q1 = knex.insert({
        SUBMISSION_REQ_TMPLT_ID,
        SUB_REQ_FORM_QSTN_NMBR,
        parent_id: parentID,
        SUB_REQ_FORMS_ID
      }).into('rcubed.SUB_REQ_FORMS_QSTN_LST');
      // if (parent_id === 0) parent_id = null;
      // eslint-disable-next-line no-await-in-loop
      await client.query(q1.toQuery());
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  // eslint-disable-next-line consistent-return
  return SUB_REQ_FORMS_ID;
};

exports.getAllSubmissionFormsShort = async (currentpage) => {
  console.log('Get all Submission form short');
  const client = await createClient();
  await client.connect();
  const q = knex.select('sf.SUB_REQ_FORMS_ID', 'sf.SUB_TYP_ID',
    'st.SUB_TYP_NM', 'sf.sub_req_forms_nm', 'sf.IS_ACTIVE')
    .from({ sf: 'rcubed.SUB_REQ_FORMS' })
    .leftOuterJoin({ st: 'rcubed.SUBMISSION_TYPE' }, 'sf.SUB_TYP_ID', '=',
      'st.SUB_TYP_ID')
    .orderBy('sf.SUB_TYP_ID');
  const r2 = await client.query(q.toQuery());
  q.limit(5);
  console.log(`current page = ${parseInt(currentpage, 10)}`);
  const offset = 5 * (currentpage - 1);
  q.offset(offset);
  console.log(`search query: ${q.toQuery()}`);
  const r = await client.query(q.toQuery());

  const result = {};
  result.rowCount = r2.rowCount;
  result.records = r.rows;
  client.end();
  return result;
};

exports.updateSubmissionForm = async (formData, SUB_REQ_FORMS_ID, lilly_id) => {
  console.log('update submission form');
  console.log(`dormdata: ${formData}`);
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  const client = await createClient();
  await client.connect();
  const d = JSON.parse(formData);
  const sub_id = d.records.SUB_REQ_FORMS.SUB_TYP_ID;
  const { sub_req_forms_nm } = d.records.SUB_REQ_FORMS;
  console.log(`sub_id: ${sub_id} Sub_req_forms_nm: ${sub_req_forms_nm}`);
  let isTrue = d.records.SUB_REQ_FORMS.IS_ACTIVE;
  const result = {};
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    let q = knex('rcubed.SUB_REQ_FORMS')
      .update({
        SUB_TYP_ID: sub_id,
        sub_req_forms_nm,
        IS_ACTIVE: isTrue
      })
      .where('SUB_REQ_FORMS_ID', SUB_REQ_FORMS_ID);
    const r = await client.query(q.toQuery());
    result.records = r.rows;
    console.log('update SUB_REQ_FORMS_product_type-ref');
    for (let i = 0; i < d.records.PRODUCT_TYPE.length; i += 1) {
      q = knex('rcubed.SUB_REQ_FORMS_PRODUCT_TYPE_REF')
        .where('SUB_REQ_FORMS_ID', SUB_REQ_FORMS_ID)
        .del();
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
      const { PRODUCT_TYPE_ID } = d.records.PRODUCT_TYPE[i];
      q = knex.insert({
        PRODUCT_TYPE_ID,
        SUB_REQ_FORMS_ID
      }).into('rcubed.SUB_REQ_FORMS_PRODUCT_TYPE_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    console.log('SUB_REQ_FORMS_DOSSIER_REF update');
    for (let i = 0; i < d.records.DOSSIER_REF.length; i += 1) {
      q = knex('rcubed.SUB_REQ_FORMS_DOSSIER_REF')
        .where('SUB_REQ_FORMS_ID', SUB_REQ_FORMS_ID)
        .del();
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
      const { DOSSIER_LST_ID } = d.records.DOSSIER_REF[i];
      q = knex.insert({
        DOSSIER_LST_ID,
        SUB_REQ_FORMS_ID
      }).into('rcubed.SUB_REQ_FORMS_DOSSIER_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    console.log('Submission forms update FORMS_QSTN_LST');
    for (let i = 0; i < d.records.FORMS_QSTN_LST.length; i += 1) {
      const sub_req_tmplt_id = parseInt(
        d.records.FORMS_QSTN_LST[i].SUBMISSION_REQ_TMPLT_ID, 10
      );
      console.log(`sub_req_tmplt_id: ${sub_req_tmplt_id}`);
      const SUB_REQ_FORM_QSTN_NMBR = parseInt(
        d.records.FORMS_QSTN_LST[i].SUB_REQ_FORM_QSTN_NMBR, 10
      );
      const { QSTN_LOGIC } = d.records.FORMS_QSTN_LST[i];
      const parentID = d.records.FORMS_QSTN_LST[i].PARENT_ID;
      const SUB_REQ_FORMS_QSTN_LST_ID = parseInt(
        d.records.FORMS_QSTN_LST[i].SUB_REQ_FORMS_QSTN_LST_ID, 10
      );
      console.log(`SUB_REQ_FORMS_QSTN_LST_ID ${SUB_REQ_FORMS_QSTN_LST_ID}`);
      isTrue = d.records.FORMS_QSTN_LST[i].IS_ACTIVE;
      if (SUB_REQ_FORMS_QSTN_LST_ID === 0) {
        console.log('Insert new question');
        q = knex.insert({
          SUBMISSION_REQ_TMPLT_ID: sub_req_tmplt_id,
          SUB_REQ_FORM_QSTN_NMBR,
          parent_id: parentID,
          SUB_REQ_FORMS_ID
        }).into('rcubed.SUB_REQ_FORMS_QSTN_LST');
        console.log(`insert new question query ${q.toQuery()}`);
        // eslint-disable-next-line no-await-in-loop
        await client.query(q.toQuery());
      } else {
        console.log('Update existing question');
        q = knex('rcubed.SUB_REQ_FORMS_QSTN_LST')
          .update({
            SUBMISSION_REQ_TMPLT_ID: sub_req_tmplt_id,
            SUB_REQ_FORM_QSTN_NMBR,
            QSTN_LOGIC,
            parent_id: parentID,
            IS_ACTIVE: isTrue
          }).where('SUB_REQ_FORMS_QSTN_LST_ID', SUB_REQ_FORMS_QSTN_LST_ID);
        console.log(`exisiting question query ${q.toQuery()}`);
        // eslint-disable-next-line no-await-in-loop
        await client.query(q.toQuery());
      }
    } await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return result;
};

exports.searchSubmissionForm = async (sub_typ_id, sub_req_forms_nm, dt,
  is_current, currentpage) => {
  console.log('search Submission form');
  console.log(`data: ${dt}`);
  const client = await createClient();
  await client.connect();
  const d = JSON.parse(dt);
  const q = knex.distinct('sf.SUB_REQ_FORMS_ID').from({ sf: 'rcubed.SUB_REQ_FORMS' })
    .leftJoin({ sfptr: 'rcubed.SUB_REQ_FORMS_PRODUCT_TYPE_REF' }, 'sf.SUB_REQ_FORMS_ID', '=', 'sfptr.SUB_REQ_FORMS_ID')
    .leftJoin({ sfdr: 'rcubed.SUB_REQ_FORMS_DOSSIER_REF' }, 'sf.SUB_REQ_FORMS_ID', '=', 'sfdr.SUB_REQ_FORMS_ID');
  // q.where((builder) => {
  console.log('search Product type');
  if (d.records.PRODUCT_TYPE.length > 1) {
    q.where((builder) => {
      for (let i = 0; i < d.records.PRODUCT_TYPE.length; i += 1) {
        // if ((d.records.PRODUCT_TYPE.length > 1) && (d.records.PRODUCT_TYPE[i].OPERATOR === 'OR')) {
        if (d.records.PRODUCT_TYPE.length > 1) {
          if (i === 0) {
            builder.where('sfptr.PRODUCT_TYPE_ID', d.records.PRODUCT_TYPE[i].PRODUCT_TYPE_ID);
          } else {
            builder.orWhere('sfptr.PRODUCT_TYPE_ID', d.records.PRODUCT_TYPE[i].PRODUCT_TYPE_ID);
          }
        }
      }
    });
    // } else if (d.records.PRODUCT_TYPE[i].OPERATOR === 'NOT') {
    //   q.whereNot(('sfptr.PRODUCT_TYPE_ID', d.records.PRODUCT_TYPE[i].PRODUCT_TYPE_ID));
  } else if (d.records.PRODUCT_TYPE.length === 1) {
    q.where('sfptr.PRODUCT_TYPE_ID', d.records.PRODUCT_TYPE[0].PRODUCT_TYPE_ID);
  }

  console.log('search Dossier lst');
  if (d.records.DOSSIER_REF.length > 1) {
    q.where((builder) => {
      for (let i = 0; i < d.records.DOSSIER_REF.length; i += 1) {
        // if ((d.records.DOSSIER_REF.length > 1) && (d.records.DOSSIER_REF[i].OPERATOR === 'OR')) {
        if (d.records.DOSSIER_REF.length > 1) {
          if (i === 0) {
            builder.where('sfdr.DOSSIER_LST_ID', d.records.DOSSIER_REF[i].DOSSIER_LST_ID);
          } else {
            builder.orWhere('sfdr.DOSSIER_LST_ID', d.records.DOSSIER_REF[i].DOSSIER_LST_ID);
          }
        }
      }
    });
  } else if (d.records.DOSSIER_REF.length === 1) {
    q.where('sfdr.DOSSIER_LST_ID', d.records.DOSSIER_REF[0].DOSSIER_LST_ID);
  }

  console.log('search forms name');
  if (sub_req_forms_nm.length > 0) {
    q.where('sf.sub_req_forms_nm', 'like',
      `%${sub_req_forms_nm}%`);
  }
  if (sub_typ_id !== 0) {
    q.where('sf.sub_typ_id', '=', sub_typ_id);
  }
  const r4 = await client.query(q.toQuery());
  q.limit(5);
  console.log(`current page = ${parseInt(currentpage, 10)}`);
  const offset = 5 * (currentpage - 1);
  q.offset(offset);
  console.log(`search query: ${q.toQuery()}`);
  const result1 = await client.query(q.toQuery());
  console.log(JSON.stringify(result1));

  if (result1.rowCount === 0) return 'no search results';
  console.log(`result1: ${JSON.stringify(result1)}`);
  const result = [];
  for (let i = 0; i < result1.rows.length; i += 1) {
    const sub_req_form_id = result1.rows[i].sub_req_forms_id;
    console.log(`sub_req_form_id: ${sub_req_form_id}`);
    // eslint-disable-next-line no-await-in-loop
    const result2 = await getSubmissionForm(sub_req_form_id, is_current, true);
    result.push(result2);
  }
  client.end();
  const r = {};
  r.rowCount = r4.rowCount;
  r.records = result;
  return r;
};

exports.searchFormNames = async (sub_typ_id, product_type, dossier_lst_id) => {
  console.log('search Submission Names');
  const client = await createClient();
  await client.connect();
  const q = knex.distinct('sf.SUB_REQ_FORMS_ID')
    .from({ sf: 'rcubed.SUB_REQ_FORMS' })
    .leftJoin({ sfptr: 'rcubed.SUB_REQ_FORMS_PRODUCT_TYPE_REF' }, 'sf.SUB_REQ_FORMS_ID', '=', 'sfptr.SUB_REQ_FORMS_ID')
    .leftJoin({ sfdr: 'rcubed.SUB_REQ_FORMS_DOSSIER_REF' }, 'sf.SUB_REQ_FORMS_ID', '=', 'sfdr.SUB_REQ_FORMS_ID');
  if (sub_typ_id !== 0) {
    q.where('sf.SUB_TYP_ID', sub_typ_id);
  }
  if (product_type !== 0) {
    q.where('sfptr.PRODUCT_TYPE_ID', product_type);
  }
  if (dossier_lst_id !== 0) {
    q.where('sfdr.DOSSIER_LST_ID', dossier_lst_id);
  }
  console.log(`query = ${q.toQuery()}`);
  const result = {};
  const r = await client.query(q.toQuery());
  result.rowCount = r.rowCount;
  result.records = r.rows;
  client.end();
  return result;
};
