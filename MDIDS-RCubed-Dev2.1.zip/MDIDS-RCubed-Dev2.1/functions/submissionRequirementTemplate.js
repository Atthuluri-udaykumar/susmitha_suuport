// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
// const { attachPaginate } = require('knex-paginate');
const decryptPW = require('./DecryptSSM');

// attachPaginate();
async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

const getsubTemp = require('./getSubmissionRequirementTemplate');
// const task = require('./task_manager');

/* {
  "data":{
  "qstn_txt":[
          {
            "REQ_QSTN_LST_TXT_ID":3,
             "Text":"drop down 1",
             "IS_ACTIVE":true
          },
          {
            "REQ_QSTN_LST_TXT_ID":4,
             "Text":"drop down 2",
             "IS_ACTIVE":true
          },
          {
            "REQ_QSTN_LST_TXT_ID":5,
             "Text":"drop down 3",
             "IS_ACTIVE":true
          },
          {
            "REQ_QSTN_LST_TXT_ID":6,
             "Text":"drop down 4",
             "IS_ACTIVE":false
          }
       ],
      "SUBMISSION_TYPE":[
    {
      "SUB_TYP_ID": 1,
      "SUB_TYP_NM": "Label Change",
      "OPERATOR": "OR"
    },
    {
      "SUB_TYP_ID": 3,
      "SUB_TYP_NM": "Molecular Registration",
      "OPERATOR": "OR"
    }
  ],
      "PRODUCT_TYPE":[
    {
      "PRODUCT_TYPE_ID":1,
      "PRODUCT_TYPE_NM": "Biological/Biotech",
      "OPERATOR": "OR"
    }
  ],

      "DOSSIER_LST": [
    {
      "DOSSIER_LST_ID": 176,
      "DOSSIER_LST_NM": "3.2.S Drug substance [name, manufacturer]",
      "OPERATOR": "OR"
    }
  ],

      "REQ_CAT_LST": [
    {
      "REQ_CAT_LST_ID": 1,
      "REQ_CAT_LST_NM": "FEES",
      "OPERATOR": "OR"
    }
  ],
  "GEN_REQ_CAT_LST": [
    {
      "GEN_REQ_CAT_LST_ID": 1,
      "GEN_REQ_CAT_LST_NM": "Process and Timing",
      "OPERATOR": "OR"
    }
  ]

}
} */

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

async function isOnList(sub_id) {
  const client = await createClient();
  await client.connect();
  const q = knex.select()
    .from('rcubed.REQ_QSTN_LST_TXT')
    .where('SUBMISSION_REQ_TMPLT_ID', sub_id);
  const result = await client.query(q.toQuery());
  console.log(`isOnList result ${result}`);
  client.end();
  return result.rows.length !== 0;
}

async function loadRefTables(sub_id, d, client) {
  console.log('insert SUBMISSION_TYPE');
  let result = true;
  try {
    let q = knex('rcubed.SUB_REQ_SUB_TYP_REF')
      .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
      .del();
    console.log(`delete query = ${q.toQuery()}`);
    if (d.data.SUBMISSION_TYPE.length >= 0) {
      await client.query(q.toQuery());
    }
    for (let i = 0; i < d.data.SUBMISSION_TYPE.length; i += 1) {
      const id = d.data.SUBMISSION_TYPE[i].SUB_TYP_ID;
      console.log(`d.data.SUBMISSION_TYPE[i].SUB_TYP_ID = ${id}`);
      q = knex.insert({
        SUBMISSION_REQ_TMPLT_ID: sub_id,
        SUB_TYP_ID: id
      }).into('rcubed.SUB_REQ_SUB_TYP_REF');
      console.log(`insert into Submission ref = ${q.toQuery()}`);
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    console.log('insert PRODUCT_TYPE');
    if (d.data.PRODUCT_TYPE.length >= 0) {
      q = knex('rcubed.SUB_REQ_PRODUCT_TYP_REF')
        .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
        .del();
      await client.query(q.toQuery());
    }
    for (let i = 0; i < d.data.PRODUCT_TYPE.length; i += 1) {
      const id = d.data.PRODUCT_TYPE[i].PRODUCT_TYPE_ID;
      q = knex.insert({
        SUBMISSION_REQ_TMPLT_ID: sub_id,
        PRODUCT_TYPE_ID: id
      }).into('rcubed.SUB_REQ_PRODUCT_TYP_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    console.log('insert REQ_CAT_LST');
    if (d.data.REQ_CAT_LST.length >= 0) {
      q = knex('rcubed.SUB_REQ_REQ_CAT_REF')
        .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
        .del();
      await client.query(q.toQuery());
    }
    for (let i = 0; i < d.data.REQ_CAT_LST.length; i += 1) {
      const id = d.data.REQ_CAT_LST[i].REQ_CAT_LST_ID;
      q = knex.insert({
        SUBMISSION_REQ_TMPLT_ID: sub_id,
        REQ_CAT_LST_ID: id
      }).into('rcubed.SUB_REQ_REQ_CAT_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    console.log('insert DOSSIER_LST');
    if (d.data.DOSSIER_LST.length >= 0) {
      q = knex('rcubed.SUB_REQ_DOSSIER_REF')
        .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
        .del();
      await client.query(q.toQuery());
    }
    for (let i = 0; i < d.data.DOSSIER_LST.length; i += 1) {
      const id = d.data.DOSSIER_LST[i].DOSSIER_LST_ID;
      q = knex.insert({
        SUBMISSION_REQ_TMPLT_ID: sub_id,
        DOSSIER_LST_ID: id
      }).into('rcubed.SUB_REQ_DOSSIER_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    console.log('insert GEN_REQ_CAT_LST');
    if (d.data.GEN_REQ_CAT_LST.length >= 0) {
      q = knex('rcubed.SUB_REQ_GEN_REQ_CAT_REF')
        .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
        .del();
      await client.query(q.toQuery());
    }
    for (let i = 0; i < d.data.GEN_REQ_CAT_LST.length; i += 1) {
      const id = d.data.GEN_REQ_CAT_LST[i].GEN_REQ_CAT_LST_ID;
      q = knex.insert({
        SUBMISSION_REQ_TMPLT_ID: sub_id,
        GEN_REQ_CAT_LST_ID: id
      }).into('rcubed.SUB_REQ_GEN_REQ_CAT_REF');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
  } catch (err) {
    result = false;
    throw err;
  }
  return result;
}

// req_qstn_txt - string with values seperated by ;
exports.saveSubmissionRequirementTemplate = async (req_type, req_question_type_id, req_qstn_txt,
  custom_allowed, lilly_id) => {
  console.log('Save submission requirement template');
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  const client = await createClient();
  await client.connect();
  const is_true = custom_allowed === 'true';
  let sub_id;
  try {
    console.log('save SUB_REQ_FORMS');
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    let q = knex.returning('SUBMISSION_REQ_TMPLT_ID')
      .insert({
        REQ_TYPE: req_type,
        REQ_QUESTION_TYPE_LST_ID: req_question_type_id,
        CUSTOM_ALLOWED: is_true
      }).into('rcubed.SUBMISSION_REQ_TMPLT');
    sub_id = await client.query(q.toQuery());

    console.log(`req_qstn_txt = ${req_qstn_txt}`);

    const sub_id_q = sub_id.rows[0].submission_req_tmplt_id;
    console.log(`sub_id_q =${sub_id_q}`);
    if (req_qstn_txt != null) {
      if (sub_id_q > 0) {
        const d = JSON.parse(req_qstn_txt);
        console.log(`data.length=${d.data.qstn_txt.length}`);

        for (let i = 0; i < d.data.qstn_txt.length; i += 1) {
          const txt = d.data.qstn_txt[i].Text;
          q = knex.insert({
            SUBMISSION_REQ_TMPLT_ID: sub_id_q,
            REQ_QSTN_TXT: txt
          }).into('rcubed.REQ_QSTN_LST_TXT');
          console.log(`REQ_QSTN_TXT.text =${txt}`);
          // eslint-disable-next-line no-await-in-loop
          await client.query(q.toQuery());
        }

        await loadRefTables(sub_id_q, d, client);
      }
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const results = {};
  results.command = sub_id.command;
  results.rowCount = sub_id.rowCount;
  // eslint-disable-next-line consistent-return
  return results;
};

// eslint-disable-next-line max-len
exports.updateSubmissionRequirementTemplate = async (sub_id,
  req_type,
  req_question_type_id,
  req_qstn_txt,
  active,
  custom_allowed,
  sendNotification,
  lilly_id) => {
  console.log(`Update submission requirement template ${sub_id}`);
  // eslint-disable-next-line no-param-reassign
  if (lilly_id === null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  const client = await createClient();
  await client.connect();
  let q;
  let chng_tmplt_id;

  // changed to false 9/8/21
  /* if (sendNotification === false) {
    chng_tmplt_id = await task.generateUpdateTemplateTask(
      sub_id, req_type, req_question_type_id, req_qstn_txt,
      active, custom_allowed, lilly_id
    );
    if (chng_tmplt_id > 0) {
      q = knex('rcubed.SUBMISSION_REQ_TMPLT')
        .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
        .update({
          IS_EDITED: true
        });
      // await client.query(q.toQuery());
      await createUpdate(lilly_id, q);
    }
    // todo kick off a task here
    return chng_tmplt_id;
  } */

  if (typeof sub_id !== 'number') { return 'Error - sub_id is required'; }
  const is_true = active === 'true';
  const isCustom = custom_allowed === 'true';

  try {
    console.log('Update template no notification start');
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    q = knex('rcubed.SUBMISSION_REQ_TMPLT')
      .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
      .update({
        req_type,
        REQ_QUESTION_TYPE_LST_ID: req_question_type_id,
        is_active: is_true,
        custom_allowed: isCustom
      });
    await client.query(q.toQuery());

    if (req_qstn_txt !== null) {
      console.log('req_qstn_txt !== null');
      const d = JSON.parse(req_qstn_txt);
      for (let i = 0; i < d.data.qstn_txt.length; i += 1) {
        const id = d.data.qstn_txt[i].REQ_QSTN_LST_TXT_ID;
        const txt = d.data.qstn_txt[i].Text;
        const qstn_txt_is_true = d.data.qstn_txt[i].IS_ACTIVE === true;
        // console.log('id='+id+', txt='+txt+', is_true='+is_true)

        if (id !== 0) {
          q = knex('rcubed.REQ_QSTN_LST_TXT')
            .where('REQ_QSTN_LST_TXT_ID', id)
            .update({
              SUBMISSION_REQ_TMPLT_ID: sub_id,
              REQ_QSTN_TXT: txt,
              IS_ACTIVE: qstn_txt_is_true
            });
          // eslint-disable-next-line no-await-in-loop
          await client.query(q.toQuery());
        } else {
          q = knex.insert({
            SUBMISSION_REQ_TMPLT_ID: sub_id,
            REQ_QSTN_TXT: txt
          }).into('rcubed.REQ_QSTN_LST_TXT');
          // eslint-disable-next-line no-await-in-loop
          await client.query(q.toQuery());
        }
      }
      await loadRefTables(sub_id, d, client);

    // eslint-disable-next-line max-len
    } else if (isOnList(sub_id)) { // List is empty but there are active list members associated with it.
      console.log(`isonlist is true for ${sub_id}`);
      q = knex('rcubed.REQ_QSTN_LST_TXT')
        .where('SUBMISSION_REQ_TMPLT_ID', sub_id)
        .update({
          IS_ACTIVE: false
        });
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return '1 row updated';
};

exports.getAllSubmissionRequirementTemplateShort = async () => {
  console.log(' Get all Submission Requirement templates id and type');
  const client = await createClient();
  await client.connect();
  const q = knex.select('SUBMISSION_REQ_TMPLT_ID', 'REQ_TYPE')
    .from('rcubed.SUBMISSION_REQ_TMPLT');
  const r = await client.query(q.toQuery());
  const result = {};
  console.log(`r = ${JSON.stringify(r)}`);
  result.records = r.rows;
  client.end();
  return result;
};

exports.getRequiremntQstnTypeLst = async () => {
  console.log('Get requiremnt question type list');
  const client = await createClient();
  await client.connect();
  const r = await client.query('select * from rcubed.REQ_QUESTION_TYPE_LST');
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

// return single active template

exports.getAllSubmissionReqTemplate = async (is_true) => {
  console.log('Get all submission requirement templates ');
  const client = await createClient();
  await client.connect();
  let result1;
  let q;
  if (is_true) {
    q = knex.select('SUBMISSION_REQ_TMPLT_ID')
      .from('rcubed.SUBMISSION_REQ_TMPLT')
      .where('IS_ACTIVE', true);
    console.log(`query1 = ${q.toQuery()}`);
    result1 = await client.query(q.toQuery());
  } else {
    q = knex.select('SUBMISSION_REQ_TMPLT_ID')
      .from('rcubed.SUBMISSION_REQ_TMPLT');
    console.log(`query1 = ${q.toQuery()}`);
    result1 = await client.query(q.toQuery());
  }
  console.log(`result1 = ${JSON.stringify(result1)}`);
  const r = [];
  for (let i = 0; i < result1.rows.length; i += 1) {
    const sub_id = result1.rows[i].submission_req_tmplt_id;
    // eslint-disable-next-line no-await-in-loop
    const result2 = await getsubTemp.getSubmissionRequirementTemplate(sub_id, is_true);
    console.log(`result2 = ${result2}`);
    r.push(result2);
  }
  client.end();
  const result = {};
  result.records = r;
  return result;
};

exports.searchSubmissionReqTemplates = async (req_typ, dt, currentpage) => {
  console.log('Search submission requirement template');
  console.log(`data: ${dt}`);
  // const pool = await createPool();
  // const client = await pool.connect();
  const d = JSON.parse(dt);
  let proTyp; let subTyp; let reqCat; let dosRef; let GenCatRef;
  if (d.data.PRODUCT_TYPE.length > 0) proTyp = true;
  if (d.data.SUBMISSION_TYPE.length > 0) subTyp = true;
  if (d.data.DOSSIER_LST.length > 0) dosRef = true;
  if (d.data.REQ_CAT_LST.length > 0) reqCat = true;
  if (d.data.GEN_REQ_CAT_LST.length > 0) GenCatRef = true;
  const q = knex.distinct('srt.SUBMISSION_REQ_TMPLT_ID').from({ srt: 'rcubed.SUBMISSION_REQ_TMPLT ' });
  if (proTyp) { q.join({ ptr: 'rcubed.SUB_REQ_PRODUCT_TYP_REF' }, 'srt.SUBMISSION_REQ_TMPLT_ID', '=', 'ptr.SUBMISSION_REQ_TMPLT_ID'); }
  if (subTyp) q.join({ str: 'rcubed.SUB_REQ_SUB_TYP_REF' }, 'srt.SUBMISSION_REQ_TMPLT_ID', '=', 'str.SUBMISSION_REQ_TMPLT_ID');
  if (reqCat) q.join({ rclr: 'rcubed.SUB_REQ_REQ_CAT_REF' }, 'srt.SUBMISSION_REQ_TMPLT_ID', '=', 'rclr.SUBMISSION_REQ_TMPLT_ID');
  if (dosRef) q.join({ rdr: 'rcubed.SUB_REQ_DOSSIER_REF' }, 'srt.SUBMISSION_REQ_TMPLT_ID', '=', 'rdr.SUBMISSION_REQ_TMPLT_ID');
  if (GenCatRef) q.join({ grr: 'rcubed.SUB_REQ_GEN_REQ_CAT_REF' }, 'srt.SUBMISSION_REQ_TMPLT_ID', '=', 'grr.SUBMISSION_REQ_TMPLT_ID');
  q.where((builder) => {
    if (proTyp) {
      console.log('search Product type');
      for (let i = 0; i < d.data.PRODUCT_TYPE.length; i += 1) {
        if ((d.data.PRODUCT_TYPE.length > 1) && (d.data.PRODUCT_TYPE[i].OPERATOR === 'OR')) {
          builder.orWhere('ptr.PRODUCT_TYPE_ID', d.data.PRODUCT_TYPE[i].PRODUCT_TYPE_ID);
        } else {
          builder.where('ptr.PRODUCT_TYPE_ID', d.data.PRODUCT_TYPE[i].PRODUCT_TYPE_ID);
        }
      }
    }
  });

  console.log('search Submission  type');
  q.where((builder) => {
    for (let i = 0; i < d.data.SUBMISSION_TYPE.length; i += 1) {
      if ((d.data.SUBMISSION_TYPE.length > 1) && (d.data.SUBMISSION_TYPE[i].OPERATOR === 'OR')) {
        builder.orWhere('str.SUB_TYP_ID', d.data.SUBMISSION_TYPE[i].SUB_TYP_ID);
      } else {
        builder.where('str.SUB_TYP_ID', d.data.SUBMISSION_TYPE[i].SUB_TYP_ID);
      }
    }
  });
  console.log('search Dossier lst');
  q.where((builder) => {
    for (let i = 0; i < d.data.DOSSIER_LST.length; i += 1) {
      if ((d.data.DOSSIER_LST.length > 1) && (d.data.DOSSIER_LST[i].OPERATOR === 'OR')) {
        builder.orWhere('rdr.DOSSIER_LST_ID', d.data.DOSSIER_LST[i].DOSSIER_LST_ID);
      } else {
        builder.where('rdr.DOSSIER_LST_ID', d.data.DOSSIER_LST[i].DOSSIER_LST_ID);
      }
    }
  });
  console.log('search Requiremnt Category list');
  q.where((builder) => {
    for (let i = 0; i < d.data.REQ_CAT_LST.length; i += 1) {
      if ((d.data.REQ_CAT_LST.length > 1) && (d.data.REQ_CAT_LST[i].OPERATOR === 'OR')) {
        builder.orWhere('rclr.REQ_CAT_LST_ID', d.data.REQ_CAT_LST[i].REQ_CAT_LST_ID);
      } else {
        builder.where('rclr.REQ_CAT_LST_ID', d.data.REQ_CAT_LST[i].REQ_CAT_LST_ID);
      }
    }
  });
  console.log('search General Requiremnt Category list');
  q.where((builder) => {
    for (let i = 0; i < d.data.GEN_REQ_CAT_LST.length; i += 1) {
      if ((d.data.GEN_REQ_CAT_LST.length > 1) && (d.data.GEN_REQ_CAT_LST[i].OPERATOR === 'OR')) {
        builder.orWhere('grr.gen_req_cat_lst_id', d.data.GEN_REQ_CAT_LST[i].GEN_REQ_CAT_LST_ID);
      } else {
        builder.where('grr.gen_req_cat_lst_id', d.data.GEN_REQ_CAT_LST[i].GEN_REQ_CAT_LST_ID);
      }
    }
  });

  console.log('search requirement type');
  if (req_typ.length > 0) { q.where('srt.req_type', 'ILIKE', `%${req_typ}%`); }
  const client = await createClient();
  await client.connect();
  const r4 = await client.query(q.toQuery());
  console.log(`row count = ${r4.rowCount}`);
  q.limit(5);
  const offset = 5 * (currentpage - 1);
  q.offset(offset);
  console.log(`search query: ${q.toQuery()}`);

  const result1 = await client.query(q.toQuery());
  console.log(`result = ${JSON.stringify(result1)}`);

  if (result1.rows.length === 0) return 'no search results';

  const result = [];

  for (let i = 0; i < result1.rows.length; i += 1) {
    const sub_id = result1.rows[i].submission_req_tmplt_id;
    // eslint-disable-next-line no-await-in-loop
    const result2 = await getsubTemp.getSubmissionRequirementTemplate(sub_id, true);
    console.log(result2);
    result.push(result2);
  }
  const r = {};
  r.rowCount = r4.rowCount;
  r.records = result;
  client.end();
  return r;
};

exports.isTemplateEdited = async (templ_id) => {
  console.log('Is Templated Edited Start');
  const client = await createClient();
  await client.connect();
  let result;
  try {
    const q = knex.select('IS_EDITED')
      .from('rcubed.SUBMISSION_REQ_TMPLT')
      .where('SUBMISSION_REQ_TMPLT_ID', templ_id);
    result = client.query(q.toQuery());
  } catch (err) {
    console.log(`Error in Is Template Edited ${err}`);
    return err;
  } finally {
    client.end();
  }
  if (result.rows.IS_EDITED === 'true') return true;

  return false;
};

exports.isQuestionInForm = async (sub_id) => {
  console.log('Is Question In a form start');
  const client = await createClient();
  await client.connect();
  let result;
  try {
    const q = knex.distinct('SUB_REQ_FORMS_ID')
      .from('rcubed.SUB_REQ_FORMS_QSTN_LST')
      .where('SUBMISSION_REQ_TMPLT_ID', sub_id);
    result = await client.query(q.toQuery());
  } catch (err) {
    console.log(`Error in is Question in a form ${err}`);
    return err;
  } finally {
    client.end();
  }
  if (result.rows.length > 0) return true;

  return false;
};

exports.isQuestionNameDuplicate = async (req_name) => {
  console.log('check for duplicate question name start');
  const client = await createClient();
  await client.connect();
  let result;
  const q = knex.distinct('req_type')
    .from('rcubed.SUBMISSION_REQ_TMPLT')
    .where('req_type', req_name)
    .where('is_active', true);
  try {
    result = await client.query(q.toQuery());
  } catch (err) {
    console.log(`Error in is Question in a form ${err}`);
    return err;
  } finally {
    client.end();
  }
  if (result.rows.length > 0) return true;

  return false;
};
