const { Client } = require('pg');
const aws = require('aws-sdk');

const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});
const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = await new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

const qstnChngTmpt = require('./questionTemplateChange');
const subChngForm = require('./submissionFormChange');

const Form_Approval = 1;
const Affiliate_Answer_Review = 2;

async function sendEmail(address, task_id) {
  console.log(`send email to ${address}`);
  const tmpltChngParams = {
    Destination: { /* required */
      CcAddresses: [],
      ToAddresses: [address]
    },
    Message: {
      Body: {
        Html: {
          Data: '<p> There was a change made in the R-Cubed system that has impacted Requirements Submission Form(s).'
              + 'A task has been created to track this process.</p>',
          Charset: 'utf-8'
        },
        Text: {
          Data: 'There was a change made in the R-Cubed system that has impacted Requirements Submission Form(s). '
              + 'A task has been created to track this process.',
          Charset: 'utf-8'
        }
      },
      Subject: {
        Data: `R-Cubed System Notification: Task ${task_id}, Question Template Change - Form Approval Needed`,
        Charset: 'utf-8'
      }
    },
    Source: 'aws-notifications-554690545045@lilly.com', /* required */
    ReplyToAddresses: [],
    SourceArn: 'arn:aws:ses:us-east-1:539199905087:identity/lilly.com'
  };
  const sesclient = new aws.SESv2({ region: 'us-east-1' });
  /* const sesclient = new SESv2Client({
    region: 'us-east-1'
  }); */
  // const command = new CreateConfigurationSetCommand(tmpltChngParams);
  // const command1 = new SendEmailCommand(tmpltChngParams);
  try {
    const sendPromise = await sesclient.sendEmail(tmpltChngParams);
    // const send1 = await sesclient1.send(command1);

    console.log(`Message ID = ${sendPromise.MessageId}`);
    // console.log(`Message ID = ${send1.MessageId}`);
    return sendPromise;
  } catch (err) {
    console.error(err, err.stack);
    return err;
  }
}

async function generateNewTask(TASK_TYPE_ID) {
  console.log('Generate new task');
  const client = await createClient();
  await client.connect();
  const q = knex.returning('TASK_TRACKER_ID')
    .insert({
      TASK_TYPE: TASK_TYPE_ID
    }).into('rcubed.TASK_TRACKER');
  const result = await client.query(q.toQuery());
  console.log(`TASK_TRACKER_ID ${JSON.stringify(result)}`);
  client.end();
  return result.rows[0].task_tracker_id;
}

async function loadTaskForms(task_id, d) {
  console.log('Load task forms');
  const client = await createClient();
  await client.connect();
  for (let i = 0; i < d.records.length; i += 1) {
    const sub_form_id = parseInt(d.records[i].sub_req_forms_id, 10);
    // console.log(`LoadTask sub form Id ${sub_form_id}`);
    const q = knex.insert({
      TASK_TRACKER_ID: task_id,
      SUB_REQ_FORMS_ID: sub_form_id
    }).into('rcubed.TASK_FORMS');
    // eslint-disable-next-line no-await-in-loop
    await client.query(q.toQuery());
  }
  client.end();
}

async function getUserAdminEmails() {
  console.log('getUserAdminEmails Start');
  console.log(`Stage: ${process.env.env_stage}`);
  const client = await createClient();
  await client.connect();
  const envStage = process.env.env_stage;
  let configEnv = 'rcubed_admin';
  if (envStage === 'dev') {
    configEnv += '_dev';
  } else if (envStage === 'qa') {
    configEnv += '_qa';
  }
  console.log(`configEnv = ${configEnv}`);
  const q = knex.distinct('u.email',)
    .from({ u: 'rcubed.users' })
    .join({ ur: 'rcubed.USER_ROLES' }, 'u.lilly_id', '=',
      'ur.lilly_id')
    .where('ur.user_roles', configEnv);
  const r = await client.query(q.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
}

exports.generateUpdateTemplateTask = async (sub_id, req_type,
  req_question_type_id, req_qstn_txt,
  active, custom_allowed, lilly_id) => {
  console.log('task.generate update Template start');
  console.log(`req_type =${req_type} req_question_type_id =${req_question_type_id}`);
  let task_id;
  const tmplt_chng_id = await qstnChngTmpt.saveChangedQuestionTemplate(sub_id, req_type,
    req_question_type_id, req_qstn_txt, active, custom_allowed, lilly_id);
  const client = await createClient();
  await client.connect();
  // get all forms that have changed and set has_changed to true
  if (tmplt_chng_id !== null) {
    console.log(`Template change ID = ${tmplt_chng_id}`);
    task_id = await generateNewTask(Form_Approval);
    // track old template id, new template id and task id
    console.log('tracking changed template plus new template');
    const q = knex.insert({
      SUBMISSION_REQ_TMPLT_ID: sub_id,
      REQ_TMPLT_CHNG_ID: tmplt_chng_id,
      TASK_TRACKER_ID: task_id
    }).into('rcubed.TASK_SUB_REQ_CHNG_REF');
    await client.query(q.toQuery());
    // save form with changed question in draft table.
    const d = await subChngForm.getChangedSubmissionForms(sub_id, tmplt_chng_id);
    console.log(`changed sub forms: ${JSON.stringify(d)}`);
    await loadTaskForms(task_id, d);
    // get admin emails
    const emails = await getUserAdminEmails();
    for (let i = 0; i < emails.records.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      // await sendEmail(emails.records[i].email, task_id);
    }
  }
  console.log(`Generate task end ${tmplt_chng_id}`);
  client.end();
  return task_id;
};

exports.completeFormReviewTask = async (task_id) => {
  console.log('Start complete task');
  const client = await createClient();
  await client.connect();
  // get old and new question ids
  let q = knex.select('SUBMISSION_REQ_TMPLT_ID', 'REQ_TMPLT_CHNG_ID')
    .from('rcubed.TASK_SUB_REQ_CHNG_REF')
    .where('TASK_TRACKER_ID', task_id);
  const d = await client.query(q.toQuery());
  console.log(`d=${JSON.stringify(d)}`);
  const old_sub_id = d.rows[0].submission_req_tmplt_id;
  const new_template_id = d.rows[0].req_tmplt_chng_id;
  /*q = knex.select('ql.SUB_REQ_FORMS_ID')
    .from({ ql: 'rcubed.SUB_REQ_FORMS_QSTN_LST' })
    .join({ f: 'rcubed.SUB_REQ_FORMS' }, 'f.SUB_REQ_FORMS_ID', '=',
      'ql.SUB_REQ_FORMS_ID')
    .where('ql.SUBMISSION_REQ_TMPLT_ID', old_sub_id)
    .where('ql.IS_ACTIVE', true);*/

  console.log(`forms query = ${q.toQuery()}`);
  const form_ids = await client.query(q.toQuery());
  console.log(`form_ids = ${JSON.stringify(form_ids)}`);
  // complete task
  q = knex('rcubed.TASK_TRACKER')
    .update({
      TASK_CMPLT: true
    })
    .where('TASK_TRACKER_ID', task_id);
  await client.query(q.toQuery());
  // move old form questions to preserve for later compare
  const p = [];
  for (let i = 0; i < form_ids.rows.length; i += 1) {
    const sub_form_id = form_ids.rows[i].SUB_REQ_FORMS_ID;
    q = knex.insert(
      knex.select('SUB_REQ_FORMS_ID', 'SUBMISSION_REQ_TMPLT_ID',
        'SUB_REQ_FORM_QSTN_NMBR', 'QSTN_LOGIC', 'PARENT_ID',
        'IS_ACTIVE')
        .from('rcubed.SUB_REQ_FORMS_QSTN_LST')
        .where('SUB_REQ_FORMS_ID', sub_form_id)
    ).into('rcubed.SUB_REQ_OLD_FORMS_QSTN_LST');
    console.log(`task complete query = ${q.toQuery()}`);
    p.push(client.query(q.toQuery()));
    // p.push(client.query('insert into rcubed.SUB_REQ_OLD_FORMS_QSTN_LST '
    //     + '(SUB_REQ_FORMS_ID, SUBMISSION_REQ_TMPLT_ID,SUB_REQ_FORM_QSTN_NMBR,'
    //     + 'QSTN_LOGIC,PARENT_ID,IS_ACTIVE) '
    //     + 'SELECT SUB_REQ_FORMS_ID,SUBMISSION_REQ_TMPLT_ID,SUB_REQ_FORM_QSTN_NMBR,'
    //     + 'QSTN_LOGIC,PARENT_ID,IS_ACTIVE from rcubed.SUB_REQ_FORMS_QSTN_LST '
    //     + 'where SUB_REQ_FORMS_ID = $1', [sub_form_id]));
  }
  const move = await Promise.all(p);
  console.log(`Move data return: ${move}`);
  const promises = [];
  // change forms to new question
  for (let i = 0; i < form_ids.rows.length; i += 1) {
    const sub_form_id = form_ids.rows[i].SUB_REQ_FORMS_ID;
    q = knex('rcubed.SUB_REQ_DRAFT_FORMS_QSTN_LST')
      .update({
        SUBMISSION_REQ_TMPLT_ID: new_template_id
      })
      .where('SUBMISSION_REQ_TMPLT_ID', old_sub_id)
      .where('SUB_REQ_FORMS_ID', sub_form_id);
    promises.push(client.query(q.toQuery()));
  }
  const result = await Promise.all(promises);
  client.end();
  return result;
};

exports.getTasksForUser = async (lilly_id) => {
  console.log(`Get task for user ${lilly_id}`);
  const client = await createClient();
  await client.connect();
  const query = knex.select('task_tracker_id')
    .from('rcubed.TASK_TRACKER')
    .where('task_assngn_to', lilly_id);
  console.log(`query = ${query.toQuery()}`);
  const r = await client.query(query.toQuery());
  client.end();
  return r.rows;
};

exports.acceptTask = async (lilly_id, task_id) => {
  console.log(`accept task ${task_id}`);
  const client = await createClient();
  await client.connect();
  const currentDate = new Date();
  const q1 = knex('rcubed.TASK_TRACKER')
    .update({
      task_accept_date: currentDate,
      task_assngn_to: lilly_id
    }).where('TASK_TRACKER_ID', task_id);
  try {
    await client.query('BEGIN');
    await client.query(q1.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return 'Task Accepted';
};

exports.assignTask = async (lilly_id, task_id, due_date) => {
  console.log(`assign task ${task_id}`);
  const client = await createClient();
  await client.connect();
  const q1 = knex.insert({
    task_due_date: due_date,
    task_assngn_to: lilly_id
  }).into('rcubed.TASK_TRACKER');
  try {
    await client.query('BEGIN');
    await client.query(q1.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return 'Task assigned';
};

exports.updateTaskDetails = async (task_id, details) => {
  console.log(`updating task details ${task_id}`);
  const client = await createClient();
  await client.connect();
  const q1 = knex('rcubed.TASK_TRACKER')
    .where('TASK_TRACKER_ID', task_id)
    .update({
      task_dtls: details
    });
  await client.query(q1.toQuery());
  client.end();
  return (' Task updated');
};

exports.getActiveTasks = async () => {
  console.log('get all incomplete tasks');
  const client = await createClient();
  await client.connect();
  const q1 = knex.select()
    .from('rcubed.TASK_TRACKER')
    .where('TASK_CMPLT', false);
  const r = await client.query(q1.toQuery());
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getUnassignedTasks = async () => {
  console.log('get unassigned task start');
  const client = await createClient();
  await client.connect();
  let q1 = knex.select('TASK_TRACKER_ID').from('rcubed.TASK_TRACKER')
    .where('task_assngn_to', 'is', null)
    .where('TASK_CMPLT', false);
  console.log(`query = ${q1.toQuery()}`);
  const r = await client.query(q1.toQuery());
  console.log(JSON.stringify(r));
  const result = {};
  result.records = r.rows;
  let r2;
  for (let i = 0; i < r.rows.length; i += 1) {
    const id = r.rows[i].task_tracker_id;
    q1 = knex.select('SUB_REQ_FORMS_ID')
      .from('rcubed.TASK_FORMS')
      .where('TASK_TRACKER_ID', id);
    // eslint-disable-next-line no-await-in-loop
    r2 = await client.query(q1.toQuery());
    console.log(JSON.stringify(r2));
    result.records[i].sub_req_forms_id = r2.rows;
  }
  for (let i = 0; i < r.rows.length; i += 1) {
    for (let ii = 0; ii < r2.rows.length; ii += 1) {
      const formID = r2.rows[ii].sub_req_forms_id;
      q1 = knex.select('sub_req_forms_nm')
        .from('rcubed.SUB_REQ_FORMS')
        .where('SUB_REQ_FORMS_ID', formID);
      // eslint-disable-next-line no-await-in-loop
      const r3 = await client.query(q1.toQuery());
      console.log(`query3 = ${q1.toQuery()}`);
      console.log(JSON.stringify(r3));
      console.log(JSON.stringify(result));

      result.records[i].sub_req_forms_id[ii].sub_req_forms_nm = r3.rows[0].sub_req_forms_nm;
    }
  }
  console.log(JSON.stringify(result));
  client.end();
  console.log('get unassigned task end');
  return result;
};

exports.getTask = async (task_id) => {
  console.log('get Task start');
  const client = await createClient();
  await client.connect();
  let q1 = knex.select('tt.task_tracker_id,tn.task_nm,tt.TASK_CMPLT,'
      + 'tt.task_dtls,tt.task_due_date,tt.task_create_date,tt.task_accept_date,'
      + 'tt.task_complete_date, tt.task_assngn_to')
    .from({ tt: 'rcubed.TASK_TRACKER' })
    .join({ tn: 'rcubed.TASK_TYPE' }, 'tn.TASK_TYPE_ID', '=', 'tt.TASK_TYPE')
    .where('tt.TASK_TRACKER_ID', task_id);
  console.log(`query = ${q1.toQuery()}`);
  const r1 = await client.query(q1.toQuery());
  console.log(`r1 = ${JSON.stringify(r1)}`);
  q1 = knex.select('tf.SUB_REQ_FORMS_ID, sf.sub_req_forms_nm, tf.is_reviewed')
    .from({ tf: 'rcubed.TASK_FORMS' })
    .join({ sf: 'rcubed.SUB_REQ_FORMS' }, 'sf.SUB_REQ_FORMS_ID', '=', 'tf.SUB_REQ_FORMS_ID')
    .where('TASK_TRACKER_ID', task_id)
    .where('IS_REVIEWED', false);
  const r2 = await client.query(q1.toQuery());
  console.log(r2);
  const result = {};
  result.records = r1.rows[0];
  result.forms = r2.rows;
  client.end();
  return result;
};

exports.rejectTask = async (task_id) => {
  console.log('reject task start');
  const client = await createClient();
  await client.connect();
  const q1 = knex('rcubed.TASK_TRACKER')
    .where('TASK_TRACKER_ID', task_id)
    .update({
      task_assngn_to: null
    });
  await client.query(q1.toQuery());
  client.end();
  return `Task ${task_id} updated`;
};

exports.isReviewed = async (task_id, SUB_REQ_FORMS_ID) => {
  console.log('isReviewed start');
  const client = await createClient();
  await client.connect();
  const q1 = knex('rcubed.TASK_FORMS')
    .where('TASK_TRACKER_ID', task_id)
    .where('SUB_REQ_FORMS_ID', SUB_REQ_FORMS_ID)
    .update(
      {
        is_reviewed: true
      }
    );
  await client.query(q1.toQuery());
  client.end();
};
