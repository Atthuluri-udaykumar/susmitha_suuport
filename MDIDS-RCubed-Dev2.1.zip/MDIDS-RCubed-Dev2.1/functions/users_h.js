// const data = require('data-api-client')({
//   secretArn: process.env.sm_db_arn,
//   resourceArn: process.env.rds_arn,
//   database: process.env.db_name,
//   keepAlive: true
// });
const { Client } = require('pg');
const knex = require('knex')({
  client: 'pg',
  wrapIdentifier: (value, origImpl, queryContext) => value
});

const decryptPW = require('./DecryptSSM');

async function createClient() {
  const dbPass = await decryptPW.getEncryptedParameter(process.env.db_pw_path);
  const client = new Client({
    user: process.env.db_user,
    host: process.env.dbEndPoint,
    database: process.env.db_name2,
    password: dbPass,
    port: 5432,
  });
  return client;
}

async function createUpdate(lilly_id, q) {
  // eslint-disable-next-line no-param-reassign
  if (lilly_id == null) lilly_id = 'unknown user';
  const values = [lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let r;
  const client = await createClient();
  await client.connect();
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    r = await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  const result = {};
  result.records = r.rows;
  return result;
}

exports.listAllUsers = async () => {
  const client = await createClient();
  await client.connect();
  const r = await client.query('SELECT * from rcubed.USERS');
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.listActiveUsers = async () => {
  const client = await createClient();
  await client.connect();
  const r = await client.query('SELECT * from rcubed.USERS where is_active = true');
  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.getUser = async (userid) => {
  const client = await createClient();
  await client.connect();
  const q = knex.select('user_id', 'Lilly_id', 'user_nm', 'email', 'is_active')
    .from('rcubed.USERS')
    .where('user_id', userid);
  const r = await client.query(q.toQuery());

  const result = {};
  result.records = r.rows;
  client.end();
  return result;
};

exports.deleteUser = async (lilly_id, admin_lilly_id) => {
  console.log('soft delete user start');
  const client = await createClient();
  await client.connect();
  const values = [admin_lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let q = knex('rcubed.USERS')
    .where('lilly_id', lilly_id)
    .update({
      is_active: false
    });
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    await client.query(q.toQuery());
    q = knex('rcubed.USER_ROLES')
      .where('LILLY_ID', lilly_id)
      .del();
    await client.query(q.toQuery());
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return 'User deactive';
};

exports.userData = async (rcubed) => {
  console.log('check user start');
  const client = await createClient();
  await client.connect();;
  let result;
  const d = JSON.parse(rcubed);
  const lillyid = d.user.lilly_id;
  const { email } = d.user;
  const { user_nm } = d.user;
  const is_true = d.user.is_active === 'true';
  const { roles } = d.user;
  const values = [d.user.lilly_id];
  const insertU = 'insert into curr_app_user (username) values($1)';
  let q = knex.insert({
    lilly_id: lillyid,
    user_nm,
    email,
    is_active: is_true
  }).into('rcubed.USERS')
    .onConflict('lilly_id').merge();
  console.log(`Lilly_id: ${lillyid}, email: ${email}, user_nm: ${user_nm}`);
  try {
    await client.query('BEGIN');
    await client.query('CREATE TEMP TABLE curr_app_user(username text)');
    await client.query(insertU, values);
    console.log(`roles = ${JSON.stringify(roles)}`);
    result = await client.query(q.toQuery());
    console.log(`roles = ${JSON.stringify(roles)}`);
    // update roles
    q = knex('rcubed.USER_ROLES')
      .where('LILLY_ID', lillyid)
      .del();
    await client.query(q.toQuery());
    for (let i = 0; i < d.user.roles.length; i += 1) {
      q = knex.insert({
        LILLY_ID: lillyid,
        USER_ROLES: d.user.roles[i].roleName
      }).into('rcubed.USER_ROLES');
      // eslint-disable-next-line no-await-in-loop
      await client.query(q.toQuery());
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.end();
  }
  return result;
};
/*
{
  "roles":[
    {
      "roleName": "some AD Group"
    },
    {
      "roleName": "some other AD group"
     }
  ]
}

 */
