export interface ICountry {
  optionId: number;
  optionText: string;
  region: number;
  isActive: boolean;
}
