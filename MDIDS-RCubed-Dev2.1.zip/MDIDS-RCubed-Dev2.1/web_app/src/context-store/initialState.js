export const initialState = {
  loading: false,
  selectedRegion: null,
  regions: null,
  user: false,
  notification: {
    message: "",
    open: false,
    color: "transparent"
  },
  show: false,
  text: "",
  title:"",
  dialogType:""
};
