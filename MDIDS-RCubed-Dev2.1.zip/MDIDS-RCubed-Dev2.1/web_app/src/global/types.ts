export interface IOption {
    optionId: number
    optionText: string
}