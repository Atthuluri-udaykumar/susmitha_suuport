import { getContainerSelectors } from "../utils";

const QuestionTemplateSelectors = getContainerSelectors("questions");

export default QuestionTemplateSelectors;
