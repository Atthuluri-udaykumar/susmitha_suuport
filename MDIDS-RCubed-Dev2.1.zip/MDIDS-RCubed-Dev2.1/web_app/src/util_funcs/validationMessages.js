export const validationMessages = {
  fieldIsRequired: "Field is required",
};
